Tab Styles Inspiration
=========

Some inspiration for tab styles and effects.

[Article on Codrops](http://tympanus.net/codrops/?p=19559)

[Demo](http://tympanus.net/Development/TabStylesInspiration/)

Integrate or build upon it for free in your personal or commercial projects. Don't republish, redistribute or sell "as-is". 

Read more here: [License](http://tympanus.net/codrops/licensing/)

Iconfont by [Pixeden](http://www.pixeden.com/icon-fonts/stroke-7-icon-font-set)

[© Codrops 2014](http://www.codrops.com)