<?php include "../../inc/dbinfo.inc"; ?>
<?php
   $ispost = false;
   $networkfilter = '';

   $agefilter = '';

   function queryfilter(&$ispost,$id_string){
     if(isset($_GET[$id_string])){
       if(strlen($_GET[$id_string]) < 1){
         return '';
       } else {
         $ispost = true;
         return $_GET[$id_string];
       }
     } else {
       return '';
     }
   }

   function dropOption($filter,$val,$showString='SameAsVal'){
     $selectedString = '';
     if($filter == $val){
       $selectedString = ' selected ';
     }
     if($showString == 'SameAsVal'){
       $showString = $val;
     }
     $echoString = "<option value=\"" . $val . "\"" . $selectedString . ">" . $showString . "</option>";
     echo($echoString);
   }

   $dentalfilter = queryfilter($ispost,'dental');
   $marketfilter = queryfilter($ispost,'market_coverage');
   $plantypefilter = queryfilter($ispost,'plan_type');
   $coverageforfilter = queryfilter($ispost,'coverage_for');
   $ishsafilter = queryfilter($ispost,'is_hsa');
   $agefilter = queryfilter($ispost,'age');
   $statefilter = queryfilter($ispost,'state');
   $ratelowerfilter = queryfilter($ispost,'rate_lower');
   $rateupperfilter = queryfilter($ispost,'rate_upper');
   $planidfilter = queryfilter($ispost,'plan_id_filter');
   $plannamefilter = queryfilter($ispost,'plan_name_filter');


   $planidins = queryfilter($ispost,'plan_id_ins');
   $issuerins = queryfilter($ispost,'issuer_ins');
   $areains = queryfilter($ispost,'area_ins');
   $areanameins = queryfilter($ispost,'area_name_ins');
   $networkins = queryfilter($ispost,'network_id_ins');
   $networknameins = queryfilter($ispost,'network_name_ins');
   $marketins = queryfilter($ispost,'market_coverage_ins');
   $dentalins = queryfilter($ispost,'dental_ins');
   $benefiturlins = queryfilter($ispost,'benefit_url_ins');
   $stateins = queryfilter($ispost,'state_ins');
   $ishsains = queryfilter($ispost,'is_hsa_ins');
   $diseaseins = queryfilter($ispost,'disease_ins');
   $metalins = queryfilter($ispost,'metal_ins');
   $outcountryins = queryfilter($ispost,'out_country_ins');
   $nationalnetworkins = queryfilter($ispost,'national_network_ins');
   $plannameins = queryfilter($ispost,'plan_name_ins');
   $plantypeins = queryfilter($ispost,'plan_type_ins');
   $bennameins = queryfilter($ispost,'ben_name_ins');
   $limqtyins = queryfilter($ispost,'limit_qty_ins');
   $exclusionsins = queryfilter($ispost,'exclusions_ins');
   $copayins = queryfilter($ispost,'copay_ins');
   $limunitins = queryfilter($ispost,'lim_unit_ins');
   $rateageins = queryfilter($ispost,'rate_age');
   $ratesubtypeins = queryfilter($ispost,'rate_sub_type_ins');
   $rateins = queryfilter($ispost,'rate_ins');



	$plan_type_ml = queryfilter($ispost,'plan_type_ml');
	$dental_only_plan_ml = queryfilter($ispost,'dental_only_plan_ml');
	$markge_coverage_ml = queryfilter($ispost,'markge_coverage_ml');
	$out_of_country_ml = queryfilter($ispost,'out_of_country_ml');
	$age_ml = queryfilter($ispost,'age_ml');
	$metal_level_ml = queryfilter($ispost,'metal_level_ml');
	$out_of_service_area_ml = queryfilter($ispost,'out_of_service_area_ml');
	$state_ml = queryfilter($ispost,'state_ml');
	$tobacco_ml = queryfilter($ispost,'tobacco_ml');


   //echo "<h1> Inside PHP </h1>";
   $conn_string = "host=" . DB_SERVER . " port=" . DB_PORT . " dbname=" . DB_DATABASE . " user=" . DB_USERNAME . " password=" . DB_PASSWORD . " connect_timeout=5";
   //echo "<p> " . $conn_string . " </p>";
   $connection = pg_connect($conn_string) or die('Could not connect: ' . pg_last_error());
   //echo "<p> connection attempt made </p>";
   if (!$connection) {
     echo "<p> An error occurred connecting to the database </p>";
     exit;
   }

   ?>
<!DOCTYPE html>
<html lang="en" class="no-js">
   <head>
      <meta charset="UTF-8" />
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>US Health Insurance</title>
      <meta name="description" content="US Health Insurance MarketPlace" />
      <meta name="keywords" content="US Health Insurance MarketPlace" />
      <meta name="author" content="CS411-Team-Rigel" />
      <link rel="shortcut icon" href="../favicon.ico">
      <link rel="stylesheet" type="text/css" href="css/normalize.css" />
      <link rel="stylesheet" type="text/css" href="css/demo.css" />
      <link rel="stylesheet" type="text/css" href="css/tabs.css" />
      <link rel="stylesheet" type="text/css" href="css/tabstyles.css" />
      <script src="js/modernizr.custom.js"></script>
   </head>
   <style type="text/css">
      .displayNone { display: none; }

.rectangle {
	fill: steelblue;

}
.rectangle:hover {
	fill: orange;

}
.axis {
  font: 12px sans-serif;
}

.axis path,
.axis line {
  fill: none;
  stroke: #000;
  shape-rendering: crispEdges;
}

.vizdropdown {
  font: 15px sans-serif;
}


*{
    box-shadow: none;
    outline: none;
}
input{
    border: 1px solid #aaaaaa;
}
input:focus:required:invalid {border: 1px solid red;}
input:required:valid { border: 1px solid #aaaaaa; }


   </style>
   <body>
      <svg class="hidden">
         <defs>
            <path id="tabshape" d="M80,60C34,53.5,64.417,0,0,0v60H80z"/>
         </defs>
      </svg>
      <div class="container">
      <!-- Top Navigation -->
      <div class="codrops-top clearfix">
         <!--a class="codrops-icon codrops-icon-prev" href=""><span>Previous Demo</span></a-->
         <a><span>US Health Insurance Market Place</span></a>
         <!--span class="right"><a class="codrops-icon codrops-icon-drop" href=""><span>About US</span></a></span-->
      </div>
      <!--header class="codrops-header">
         <h1>Tab Styles Inspiration <span>A small collection of styles for tabs</span></h1>

         </header-->
      <section>
         <div class="tabs tabs-style-shape">
            <nav>
               <ul>
                  <li>
                     <a href="#section-shape-1">
                        <svg viewBox="0 0 80 60" preserveAspectRatio="none">
                           <use xlink:href="#tabshape"></use>
                        </svg>
                        <span>Search</span>
                     </a>
                  </li>
                  <li>
                     <a href="#section-shape-2">
                        <svg viewBox="0 0 80 60" preserveAspectRatio="none">
                           <use xlink:href="#tabshape"></use>
                        </svg>
                        <svg viewBox="0 0 80 60" preserveAspectRatio="none">
                           <use xlink:href="#tabshape"></use>
                        </svg>
                        <span>Create</span>
                     </a>
                  </li>
                  <li>
                     <a href="#section-shape-3">
                        <svg viewBox="0 0 80 60" preserveAspectRatio="none">
                           <use xlink:href="#tabshape"></use>
                        </svg>
                        <svg viewBox="0 0 80 60" preserveAspectRatio="none">
                           <use xlink:href="#tabshape"></use>
                        </svg>
                        <span>Get Quote</span>
                     </a>
                  </li>
                  <li>
                     <a href="#section-shape-4">
                        <svg viewBox="0 0 80 60" preserveAspectRatio="none">
                           <use xlink:href="#tabshape"></use>
                        </svg>
                        <svg viewBox="0 0 80 60" preserveAspectRatio="none">
                           <use xlink:href="#tabshape"></use>
                        </svg>
                        <span>Analytics</span>
                     </a>
                  </li>
                  <li>
                     <a href="#section-shape-5">
                        <svg viewBox="0 0 80 60" preserveAspectRatio="none">
                           <use xlink:href="#tabshape"></use>
                        </svg>
                        <span>Help</span>
                     </a>
                  </li>
               </ul>
            </nav>
            <div class="content-wrap">

               <section id="section-shape-1">
                  <table class="table1">
                     <tr class="tr1" align="left">
                        <td class="td1">Enter Details for Search</td>
                     </tr>
                     <form >
                        <tr class="tr3" align="left">
                           <td class="td3">
                              <label for="market_coverage">Market Coverage:<br>
                              <select name="market_coverage" id="market_coverage">
                                 <option value="">Any</option>
                                 <?php dropOption($marketfilter,'Individual'); ?>
                                 <?php dropOption($marketfilter,'Family'); ?>
                                 <?php dropOption($marketfilter,'SHOP (Small Group)'); ?>
                              </select>
                           </td>
                           <td class="td3">
                              <label for="is_hsa">HSA Eligible:<br>
                              <select name="is_hsa" id="is_hsa">
                                 <option value="">Either</option>
                                 <?php dropOption($ishsafilter,'Yes'); ?>
                                 <?php dropOption($ishsafilter,'No'); ?>
                              </select>
                           </td>
                           <td class="td3">
                              <label for="coverage_for">Coverge For:<br>
                              <select name="coverage_for" id="coverage_for">
                                 <option value="">Any</option>
                                 <?php dropOption($coverageforfilter,'individualrate','Just You'); ?>
                                 <?php dropOption($coverageforfilter,'couple','Couple'); ?>
                                 <?php dropOption($coverageforfilter,'primarysubscriberandonedependent','You and one dependent'); ?>
                                 <?php dropOption($coverageforfilter,'primarysubscriberandtwodependents','You and two dependents'); ?>
                                 <?php dropOption($coverageforfilter,'primarysubscriberandthreeormoredependents','You and three or more dependents'); ?>
                                 <?php dropOption($coverageforfilter,'coupleandonedependent','Couple and one dependent'); ?>
                                 <?php dropOption($coverageforfilter,'coupleandtwodependents','Couple and two dependents'); ?>
                                 <?php dropOption($coverageforfilter,'coupleandthreeormoredependents','Couple and three or more dependents'); ?>
                              </select>
                           </td>
                        </tr>
                        <tr class="tr3" align="left">
                           <td class="td3">
                              <label for="plan_type">Plan Type:<br>
                              <select name="plan_type" id="plan_type">
                                 <option value="">Any</option>
                                 <?php dropOption($plantypefilter,'PPO'); ?>
                                 <?php dropOption($plantypefilter,'HMO'); ?>
                                 <?php dropOption($plantypefilter,'EPO'); ?>
                                 <?php dropOption($plantypefilter,'POS'); ?>
                                 <?php dropOption($plantypefilter,'Indemnity'); ?>
                              </select>
                           </td>
                           <td class="td3">
                              <label for="age">Age:<br>
                              <select name="age" id="age">
                                 <option value="">Select</option>
                                 <?php dropOption($agefilter,'0-20'); ?>
                                 <?php dropOption($agefilter,'21'); ?>
                                 <?php dropOption($agefilter,'22'); ?>
                                 <?php dropOption($agefilter,'23'); ?>
                                 <?php dropOption($agefilter,'24'); ?>
                                 <?php dropOption($agefilter,'25'); ?>
                                 <?php dropOption($agefilter,'26'); ?>
                                 <?php dropOption($agefilter,'27'); ?>
                                 <?php dropOption($agefilter,'28'); ?>
                                 <?php dropOption($agefilter,'29'); ?>
                                 <?php dropOption($agefilter,'30'); ?>
                                 <?php dropOption($agefilter,'31'); ?>
                                 <?php dropOption($agefilter,'32'); ?>
                                 <?php dropOption($agefilter,'33'); ?>
                                 <?php dropOption($agefilter,'34'); ?>
                                 <?php dropOption($agefilter,'35'); ?>
                                 <?php dropOption($agefilter,'36'); ?>
                                 <?php dropOption($agefilter,'37'); ?>
                                 <?php dropOption($agefilter,'38'); ?>
                                 <?php dropOption($agefilter,'39'); ?>
                                 <?php dropOption($agefilter,'40'); ?>
                                 <?php dropOption($agefilter,'41'); ?>
                                 <?php dropOption($agefilter,'42'); ?>
                                 <?php dropOption($agefilter,'43'); ?>
                                 <?php dropOption($agefilter,'44'); ?>
                                 <?php dropOption($agefilter,'45'); ?>
                                 <?php dropOption($agefilter,'46'); ?>
                                 <?php dropOption($agefilter,'47'); ?>
                                 <?php dropOption($agefilter,'48'); ?>
                                 <?php dropOption($agefilter,'49'); ?>
                                 <?php dropOption($agefilter,'50'); ?>
                                 <?php dropOption($agefilter,'51'); ?>
                                 <?php dropOption($agefilter,'52'); ?>
                                 <?php dropOption($agefilter,'53'); ?>
                                 <?php dropOption($agefilter,'54'); ?>
                                 <?php dropOption($agefilter,'55'); ?>
                                 <?php dropOption($agefilter,'56'); ?>
                                 <?php dropOption($agefilter,'57'); ?>
                                 <?php dropOption($agefilter,'58'); ?>
                                 <?php dropOption($agefilter,'59'); ?>
                                 <?php dropOption($agefilter,'60'); ?>
                                 <?php dropOption($agefilter,'61'); ?>
                                 <?php dropOption($agefilter,'62'); ?>
                                 <?php dropOption($agefilter,'63'); ?>
                                 <?php dropOption($agefilter,'64'); ?>
                                 <?php dropOption($agefilter,'65'); ?>
                                 <?php dropOption($agefilter,'65 and over'); ?>
                                 <?php dropOption($agefilter,'Family Option'); ?>
                              </select>
                           </td>
                           <td class="td3">
                              Rate Lower Limit:<br> <input type="text" name="rate_lower" value="<?=$ratelowerfilter?>">
                           </td>
                        </tr>
                        <tr class="tr3" align="left">
                           <td class="td3">
                              <label for="dental">Dental Only Plan:<br>
                              <select name="dental" id="dental">
                                 <option value="">Either</option>
                                 <?php dropOption($dentalfilter,'Yes'); ?>
                                 <?php dropOption($dentalfilter,'No'); ?>
                              </select>
                           </td>
                           <td class="td3">
                              <label for="state">State: <br>
                              <select name="state" id="state">
                                 <option value="">Select</option>
                                 <?php dropOption($statefilter,'AK'); ?>
                                 <?php dropOption($statefilter,'AL'); ?>
                                 <?php dropOption($statefilter,'AR'); ?>
                                 <?php dropOption($statefilter,'AZ'); ?>
                                 <?php dropOption($statefilter,'DE'); ?>
                                 <?php dropOption($statefilter,'FL'); ?>
                                 <?php dropOption($statefilter,'GA'); ?>
                                 <?php dropOption($statefilter,'HI'); ?>
                                 <?php dropOption($statefilter,'IA'); ?>
                                 <?php dropOption($statefilter,'IL'); ?>
                                 <?php dropOption($statefilter,'IN'); ?>
                                 <?php dropOption($statefilter,'KS'); ?>
                                 <?php dropOption($statefilter,'LA'); ?>
                                 <?php dropOption($statefilter,'ME'); ?>
                                 <?php dropOption($statefilter,'MI'); ?>
                                 <?php dropOption($statefilter,'MO'); ?>
                                 <?php dropOption($statefilter,'MS'); ?>
                                 <?php dropOption($statefilter,'MT'); ?>
                                 <?php dropOption($statefilter,'NC'); ?>
                                 <?php dropOption($statefilter,'ND'); ?>
                                 <?php dropOption($statefilter,'NE'); ?>
                                 <?php dropOption($statefilter,'NH'); ?>
                                 <?php dropOption($statefilter,'NJ'); ?>
                                 <?php dropOption($statefilter,'NM'); ?>
                                 <?php dropOption($statefilter,'NV'); ?>
                                 <?php dropOption($statefilter,'OH'); ?>
                                 <?php dropOption($statefilter,'OK'); ?>
                                 <?php dropOption($statefilter,'OR'); ?>
                                 <?php dropOption($statefilter,'PA'); ?>
                                 <?php dropOption($statefilter,'SC'); ?>
                                 <?php dropOption($statefilter,'SD'); ?>
                                 <?php dropOption($statefilter,'TN'); ?>
                                 <?php dropOption($statefilter,'TX'); ?>
                                 <?php dropOption($statefilter,'UT'); ?>
                                 <?php dropOption($statefilter,'VA'); ?>
                                 <?php dropOption($statefilter,'WI'); ?>
                                 <?php dropOption($statefilter,'WV'); ?>
                                 <?php dropOption($statefilter,'WY'); ?>
                              </select>
                           </td>
                           <td class="td3">
                              Rate Upper Limit: <br>
                              <input type="text" name="rate_upper" value="<?=$rateupperfilter?>">
                           </td>
                        </tr>
                        <tr class="tr3" align="left">
                           <td class="td3">
                              Plan Id:<br>
                              <input type="text" name="plan_id_filter" value="<?=$planidfilter?>">
                           </td>
                           <td class="td3">
                              <!--form class="form-items" action="" method="get">
                                 Plan Name:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                 <input type="text" name="PlanMarketingNameSrch">
                                 </form-->
                              Plan Name:<br>
                              <input type="text" name="plan_name_filter" value="<?=$plannamefilter?>" id="PlanMarketingNameSrch" />
                              <br/>
                           </td>
                           <td class="td3">
                           </td>
                        </tr>
                        <tr class="tr3" align="center">
                           <td class="td3"></td>
                           <td class="td3">
                              <input type="submit" name="SearchButton" id="SearchButton" value="Search" /><br/>
                           </td>
                           <td class="td3"></td>
                        </tr>
                     </form>
                  </table>
                  </br>
                  <table class="table1">
                     <tr class="tr1" align="left">
                        <td class="td1">Search Results</td>
                     </tr>
                  </table>
                  <table class="table2" >
                     <tr class="tr2" align="left">
                        <td class="td2"><b>Plan Name</b></td>
                        <td class="td2"><b>Plan ID</b></td>
                        <td class="td2"><b>State</b></td>
                        <td class="td2"><b>Plan Type</b></td>
                        <td class="td2"><b>Dental Plan</b></td>
                        <td class="td2"><b>HSA Plan</b></td>
                        <td class="td2"><b>Market Coverage</b></td>
                        <td class="td2"><b>Age</b></td>
                        <td class="td2"><b>Premium</b></td>
                        <td class="td2"><b>View/Edit</b></td>
                        <td class="td2"><b>Delete</b></td>
                     </tr>
                     <?php
                        if(isset($_GET['SearchButton'])){ //check if form was submitted
                          //$message = "Success! You entered: ".$input;
                          // PlanId,PlanMarketingName,PlanType,MarketCoverage,DentalOnlyPlan,DiseasesCovered,
                          // DrugDeductibles,MetalLevel,PlanBrochure,EnrollmentURL,BenefitsCoverageURL,NetworkId,ServiceAreaId
                          $coverateRateCol = 'individualrate';
                          if($coverageforfilter != ''){$coverateRateCol = $coverageforfilter;}

                          $sqlquery = "SELECT
                          plan_key
                          ,planmarketingname
                          ,planid
                          , statecode
                          , plantype
                          , dentalonlyplan
                          , ishsaeligible
                          , marketcoverage
                          , age
                          , $coverateRateCol
                          FROM public.plans_w_rates
                          where 1=1\n";
                          if($statefilter != ''){$sqlquery .= "AND statecode = '$statefilter' \n";}
                          if($agefilter != ''){$sqlquery .= "AND age = '$agefilter' \n";}
                          if($marketfilter != ''){$sqlquery .= "AND marketcoverage = '$marketfilter' \n";}
                          if($plantypefilter != ''){$sqlquery .= "AND plantype = '$plantypefilter' \n";}
                          if($dentalfilter != ''){$sqlquery .= "AND dentalonlyplan = '$dentalfilter' \n";}
                          if($ishsafilter != ''){$sqlquery .= "AND ishsaeligible = '$ishsafilter' \n";}
                          if($planidfilter != ''){$sqlquery .= "AND planid = '$planidfilter' \n";}
                          if($plannamefilter != ''){$sqlquery .= "AND planmarketingname like '%$plannamefilter%' \n";}
                          if(is_numeric($ratelowerfilter)){$sqlquery .= "AND $coverateRateCol >= '$ratelowerfilter' \n";}
                          if(is_numeric($rateupperfilter)){$sqlquery .= "AND $coverateRateCol <= '$rateupperfilter' \n";}
                          if($coverageforfilter != ''){$sqlquery .= "AND $coverateRateCol IS NOT NULL \n";}
                          //and statecode like '$querystatefilter'
                          //and dentalonlyplan like '$querydentalfilter'
                          //and age like '$queryagefilter'
                          $sqlquery .= "LIMIT 100";
                          //echo "<script type='text/javascript'>alert('$sqlquery');</script>";
                          //echo("<p> $sqlquery </p>");



                          //$sqlquery = "SELECT distinct p.PlanId, p.PlanMarketingName, p.PlanType, p.MarketCoverage, p.DentalOnlyPlan, '70.34' as approxprem
                        	//FROM public.plans p
                        	//where lower(p.PlanMarketingName) like '%"; //%united%';
                        	//$sqlquery .= $_GET['PlanMarketingNameSrch'];
                        	//$sqlquery .= "%' order by p.planid;	";

                        	//var_dump($_POST);

                        	//echo $_GET['PlanMarketingNameSrch'];

                        	$result = pg_query($connection, $sqlquery);

                        		if (!$result) {
                        		  echo "<h1> An error occurred selecting data from the database </h1>";
                        		  exit;
                        		}


                        	while($query_data = pg_fetch_row($result)) {
                        	  echo "<tr class='tr222'>";
                        	  echo "<td class='td222'>",$query_data[1], "</td>",
                        		   "<td class='td222'>",$query_data[2], "</td>",
                        		   "<td class='td222'>",$query_data[3], "</td>",
                        		   "<td class='td222'>",$query_data[4], "</td>",
                        		   "<td class='td222'>",$query_data[5], "</td>",
                        		   "<td class='td222'>",$query_data[6], "</td>",
                               "<td class='td222'>",$query_data[7], "</td>",
                               "<td class='td222'>",$query_data[8], "</td>",
                               "<td class='td222'>",$query_data[9], "</td>",
                        		   "<td class='td222'><form method='post'><button type='submit' name='EditButton' id='EditButton' value='$query_data[0]'>View/Edit</button><br/></form></td>",
                        		   "<td class='td222'><form method='post'><button type='submit' name='DeleteButton' id='DeleteButton' value='$query_data[0]'>Delete</button><br/></form></td>";
                        	  echo "</tr>";
                        	}

                        	// Free resultset
                        	pg_free_result($result);

                        	// Closing connection
                        //	pg_close($connection);

                        }
                        ?>
                     <?php
                        ///////////////////////////////
                        // THIS IS FOR DELETE BUTTON
                        ///////////////////////////////
                        if(isset($_POST['DeleteButton'])){ //check if form was submitted
                          $deleteplankey = $_POST['DeleteButton'];
                          //$message = "Success! You entered: ".$input;
                          // PlanId,PlanMarketingName,PlanType,MarketCoverage,DentalOnlyPlan,DiseasesCovered,
                          // DrugDeductibles,MetalLevel,PlanBrochure,EnrollmentURL,BenefitsCoverageURL,NetworkId,ServiceAreaId
                        	//$delQuery = "delete from public.plans p where p.planid in ( ";
                          $delQuery = "SELECT public.delete_plan('$deleteplankey')";
                          //$delQuery .= "SELECT distinct p.PlanId
                        	//FROM public.plans p
                        	//where lower(p.PlanMarketingName) like '%";
                        	//$delQuery .= $_GET['PlanMarketingNameSrch'];
                        	//$delQuery .= "%' order by p.planid LIMIT 1);	";

                        	$result = pg_query($connection, $delQuery);
                        	pg_free_result($result);


                        	//header("Refresh:0");
                        	//header('Location: '.$_SERVER['REQUEST_URI']);
                        	//echo "<script type='text/javascript'>window.location.reload();</script>";
                        	//$page = $_SERVER['PHP_SELF'];
                        	//$sec = "1";
                        	//header("Refresh: $sec; url=$page");

                        	echo "<script type='text/javascript'>alert('Record has been deleted');</script>";
                        	//echo "<script type='text/javascript'>if(!alert('Record has been deleted!')){window.location.reload();};</script>";


                        	// Free resultset
                        	pg_free_result($result);

                        	// Closing connection
                        	//pg_close($connection);

                        }
                        ?>
                     <?php
                        ///////////////////////////////
                        // THIS IS FOR VIEW/EDIT BUTTON
                        ///////////////////////////////
                        if(isset($_POST['EditButton'])){ //check if form was submitted
                          //$message = "Success! You entered: ".$input;
                        //	echo "<script type='text/javascript'>alert('Record has been deleted');</script>";
$viewplankey = $_POST['EditButton'];
$sqlquery = "select
p.PlanId,
p.diseasemanagementprogramsoffered,
p.urlforsummaryofbenefitscoverage,
p.StateCode,
p.PlanMarketingName,
p.NetworkId,
s.ServiceAreaName,
p.PlanType,
p.MetalLevel,
n.NetworkName,
s.CoverEntireState,
p.MarketCoverage,
p.PlanBrochure,
n.NetworkURL,
s.ZipCodes,
p.DentalOnlyPlan,
p.ServiceAreaId,
b.BenefitName,
b.LimitQty,
b.Exclusions,
b.copayinntier1,
b.LimitUnit,
r.individualrate
from public.factplanattributes p
inner join public.dimbenefitscostsharing b
on b.plan_key = p.plan_key
inner join public.dimrate r
on p.component_key = r.component_key
left join public.dimnetwork n
on p.network_key = n.network_key
left join public.dimservicearea s
on p.area_key = s.area_key
where p.plan_key = '$viewplankey'
limit 1;"; //%united%';


                        	//var_dump($_POST);

                        	//echo $_GET['PlanMarketingNameSrch'];

                        	$result = pg_query($connection, $sqlquery);

                        		if (!$result) {
                        		  echo "<h1> An error occurred selecting data from the database </h1>";
                        		  exit;
                        		}


                        	$query_data = pg_fetch_row($result);

                        	// Free resultset
                        	pg_free_result($result);


                        						echo "

                        						<table class='table1'>
                        							<tr class='tr1' align='left'> <td class='td1'><b>View/Edit Plan</b></td></tr>
                        						</table>

                        						<form method='post'>
                        						  <table class='table1'>
                        							<tr class='tr3' align='left'> <td class='td3'>Plan Details:</td></tr>
                        							<tr class='tr3' align='left'>
                                      <td class='td3'>
                                         Plan Id:<br> <input type='text' name='EditPlanID' value='".$query_data[0]."' required>
                                      </td>
                        								<td class='td3'>
                        									  DiseasesCovered:<br> <input type='text' name='EditDiseasesCovered' value='".$query_data[1]."'>
                        								</td>
                        								<td class='td3'>
                        									  Benefits Coverage URL:<br> <input type='text' name='EditBenefitsCoverageURL' value='".$query_data[2]."'>
                        								</td>
                        								<td class='td3'>
                        									  State Code:<br> <input type='text' name='EditStateCode' value='".$query_data[3]."'>
                        								</td>
                        							</tr>

                        							<tr class='tr3' align='left'>
                        								<td class='td3'>
                        									  Plan Marketing Name:<br> <input type='text' name='EditPlanMarketingName' value='".$query_data[4]."'>
                        								</td>
                        								<td class='td3'>
                        									  Drug Deductibles:<br> <input type='text' name='EditDrugDeductibles' value=\"\">
                        								</td>
                        								<td class='td3'>
                        									  Network Id:<br> <input type='text' name='EditNetworkId' value='".$query_data[5]."'>
                        								</td>
                        								<td class='td3'>
                        									  Service Area Name:<br> <input type='text' name='EditServiceAreaName' value='".$query_data[6]."'>
                        								</td>
                        							</tr>


                        							<tr class='tr3' align='left'>
                        								<td class='td3'>
                        									  Plan Type:<br> <input type='text' name='EditPlanType' value='".$query_data[7]."'>
                        								</td>
                        								<td class='td3'>
                        									  Metal Level:<br> <input type='text' name='EditMetalLevel' value='".$query_data[8]."'>
                        								</td>
                        								<td class='td3'>
                        									  Network Name:<br> <input type='text' name='EditNetworkName' value='".$query_data[9]."'>
                        								</td>
                        								<td class='td3'>
                        									  Cover Entire State:<br> <input type='text' name='EditCoverEntireState' value='".$query_data[10]."'>
                        								</td>
                        							</tr>

                        							<tr class='tr3' align='left'>
                        								<td class='td3'>
                        									  Market Coverage:<br> <input type='text' name='EditMarketCoverage' value='".$query_data[11]."'>
                        								</td>
                        								<td class='td3'>
                        									  Plan Brochure:<br> <input type='text' name='EditPlanBrochure' value='".$query_data[12]."'>
                        								</td>
                        								<td class='td3'>
                        									  Network URL:<br> <input type='text' name='EditNetworkURL' value='".$query_data[13]."'>
                        								</td>
                        								<td class='td3'>
                        									  Zip Codes:<br> <input type='text' name='EditZipCodes' value='".$query_data[14]."'>
                        								</td>
                        							</tr>


                        							<tr class='tr3' align='left'>
                        								<td class='td3'>
                        									  Dental Only Plan:<br> <input type='text' name='EditDentalOnlyPlan' value='".$query_data[15]."'>
                        								</td>
                        								<td class='td3'>
                        									  Enrollment URL:<br> <input type='text' name='EditEnrollmentURL' value=\"\">
                        								</td>
                        								<td class='td3'>
                        									  Service Area Id:<br> <input type='text' name='EditServiceAreaId' value='".$query_data[16]."'>
                        								</td>

                        							</tr>


                        							</table>



                        						</br>



                        						  <table class='table1'>
                        							<tr class='tr3' align='left'> <td class='td3'>Benefits Details:</td></tr>
                        							<tr class='tr3' align='left'>
                        								<td class='td3'>
                        									  Benefit Name:<br> <input type='text' name='EditBenefitName' value='".$query_data[17]."'>
                        								</td>
                        								<td class='td3'>
                        									  Limit Quantity:<br> <input type='text' name='EditLimitQty' value='".$query_data[18]."'>
                        								</td>
                        								<td class='td3'>
                        									  Exclusions:<br> <input type='text' name='EditExclusions' value='".$query_data[19]."'>
                        								</td>
                        							</tr>

                        							<tr class='tr3' align='left'>
                        								<td class='td3'>
                        									  CoPay:<br> <input type='text' name='EditCoPay' value='".$query_data[20]."'>
                        								</td>
                        								<td class='td3'>
                        									  LimitUnit:<br> <input type='text' name='EditLimitUnit' value='".$query_data[21]."'>
                        								</td>

                        							</tr>



                        						  </table>

                        							</br>

                        						  <table class='table1'>
                        							<tr class='tr3' align='left'> <td class='td3'>Rate Details:</td></tr>

                        							<tr class='tr3' align='left'>
                        								<td class='td3'>
                        									  Rate Type:<br> <input type='text' name='EditRateType' value=\"\">
                        								</td>
                        								<td class='td3'>
                        									  Rate Sub Type:<br> <input type='text' name='EditRateSubType' value=\"\">
                        								</td>
                        								<td class='td3'>
                        									  Rate:<br> <input type='text' name='EditRate' value='".$query_data[22]."'>
                        								</td>
                        							</tr>



                        						  </table>


                        						  <br>
                        						<button type='submit' name='SaveChanges' id='SaveChanges' value='$viewplankey'>Save Changes</button><br/>
                        						 </form>";


                        	// Free resultset
                        	pg_free_result($result);

                        	// Closing connection
                        	//pg_close($connection);

                        }
                        ?>
                     <?php
                        ///////////////////////////////
                        // THIS IS FOR VIEW/EDIT BUTTON
                        ///////////////////////////////
                        if(isset($_POST['SaveChanges'])){ //check if form was submitted
                          //$message = "Success! You entered: ".$input;
                        //	echo "<script type='text/javascript'>alert('Record has been deleted');</script>";
                          $saveplankey = $_POST['SaveChanges'];
                        	$sqlquery = "update public.factplanattributes
                          set PlanMarketingName = '".$_POST['EditPlanMarketingName']."',
                          PlanId = '".$_POST['EditPlanID']."',
                          diseasemanagementprogramsoffered = '".$_POST['EditDiseasesCovered']."',
                          urlforsummaryofbenefitscoverage = '".$_POST['EditBenefitsCoverageURL']."',
                          StateCode = '".$_POST['EditStateCode']."',
                          NetworkId = '".$_POST['EditNetworkId']."',
                          PlanType = '".$_POST['EditPlanType']."',
                          MetalLevel = '".$_POST['EditMetalLevel']."',
                          MarketCoverage = '".$_POST['EditMarketCoverage']."',
                          PlanBrochure = '".$_POST['EditPlanBrochure']."',
                          DentalOnlyPlan = '".$_POST['EditDentalOnlyPlan']."',
                          ServiceAreaId = '".$_POST['EditServiceAreaId']."'
                          where plan_key = '$saveplankey'"; //%united%';


                          //echo ("<p> $sqlquery </p>");
                        	//var_dump($_POST);

                        	//echo $_GET['PlanMarketingNameSrch'];

                        	$result = pg_query($connection, $sqlquery);

                        	echo "<script type='text/javascript'>alert('$sqlquery');</script>";
                        	//echo "<script type='text/javascript'>if(!alert('Record UPDATED successfully')){window.location.reload();};</script>";


                        	//$query_data = pg_fetch_row($result);

                        	// Free resultset
                        	pg_free_result($result);

                        	// Free resultset
                        	pg_free_result($result);

                        	// Closing connection
                        	//pg_close($connection);

                        }
                        ?>
                  </table>
               </section>
               <section id="section-shape-2">
                  <form action="">
                     <table class="table1">
                        <tr class="tr3" align="left">
                           <td class="td3">Enter Plan Details:</td>
                        </tr>
                        <tr class="tr3" align="left">
                           <td class="td3">
                              Plan Id:<br> <input type="text" name="plan_id_ins" value="<?=$planidins?>" required>
                           </td>
                           <td class="td3">
                              Diseases Covered:<br> <input type="text" name="disease_ins" value="<?=$diseaseins?>">
                           </td>
                           <td class="td3">
                              Benefits Coverage URL:<br> <input type="text" name="benefit_url_ins" value="<?=$benefiturlins?>">
                           </td>
                           <td class="td3">
                              <label for="state_ins">State Code: <br>
                              <select name="state_ins" id="state_ins" required>
                                 <option value="AK">AK</option>
                                 <?php dropOption($stateins,'AL'); ?>
                                 <?php dropOption($stateins,'AR'); ?>
                                 <?php dropOption($stateins,'AZ'); ?>
                                 <?php dropOption($stateins,'DE'); ?>
                                 <?php dropOption($stateins,'FL'); ?>
                                 <?php dropOption($stateins,'GA'); ?>
                                 <?php dropOption($stateins,'HI'); ?>
                                 <?php dropOption($stateins,'IA'); ?>
                                 <?php dropOption($stateins,'IL'); ?>
                                 <?php dropOption($stateins,'IN'); ?>
                                 <?php dropOption($stateins,'KS'); ?>
                                 <?php dropOption($stateins,'LA'); ?>
                                 <?php dropOption($stateins,'ME'); ?>
                                 <?php dropOption($stateins,'MI'); ?>
                                 <?php dropOption($stateins,'MO'); ?>
                                 <?php dropOption($stateins,'MS'); ?>
                                 <?php dropOption($stateins,'MT'); ?>
                                 <?php dropOption($stateins,'NC'); ?>
                                 <?php dropOption($stateins,'ND'); ?>
                                 <?php dropOption($stateins,'NE'); ?>
                                 <?php dropOption($stateins,'NH'); ?>
                                 <?php dropOption($stateins,'NJ'); ?>
                                 <?php dropOption($stateins,'NM'); ?>
                                 <?php dropOption($stateins,'NV'); ?>
                                 <?php dropOption($stateins,'OH'); ?>
                                 <?php dropOption($stateins,'OK'); ?>
                                 <?php dropOption($stateins,'OR'); ?>
                                 <?php dropOption($stateins,'PA'); ?>
                                 <?php dropOption($stateins,'SC'); ?>
                                 <?php dropOption($stateins,'SD'); ?>
                                 <?php dropOption($stateins,'TN'); ?>
                                 <?php dropOption($stateins,'TX'); ?>
                                 <?php dropOption($stateins,'UT'); ?>
                                 <?php dropOption($stateins,'VA'); ?>
                                 <?php dropOption($stateins,'WI'); ?>
                                 <?php dropOption($stateins,'WV'); ?>
                                 <?php dropOption($stateins,'WY'); ?>
                              </select>
                           </td>
                        </tr>
                        <tr class="tr3" align="left">
                           <td class="td3">
                              Plan Marketing Name:<br> <input type="text" name="plan_name_ins" value="<?=$plannameins?>" required>
                           </td>
                           <td class="td3">
                              <label for="is_hsa_ins">HSA Eligible:<br>
                              <select name="is_hsa_ins" id="is_hsa_ins">
                                 <option value="Yes">Yes</option>
                                 <?php dropOption($ishsains,'No'); ?>
                              </select>
                           </td>
                           <td class="td3">
                              Network Id:<br> <input type="text" name="network_ins" value="<?=$networkins?>" required>
                           </td>
                           <td class="td3">
                              Service Area Name:<br> <input type="text" name="area_name_ins" value="<?=$areanameins?>" required>
                           </td>
                        </tr>
                        <tr class="tr3" align="left">
                           <td class="td3">
                              <label for="plan_type_ins">Plan Type:<br>
                              <select name="plan_type_ins" id="plan_type_ins" required>
                                 <option value="PPO">PPO</option>
                                 <?php dropOption($plantypeins,'HMO'); ?>
                                 <?php dropOption($plantypeins,'EPO'); ?>
                                 <?php dropOption($plantypeins,'POS'); ?>
                                 <?php dropOption($plantypeins,'Indemnity'); ?>
                              </select>
                           </td>
                           <td class="td3">
                              <label for="metal_ins">Metal Level:<br>
                              <select name="metal_ins" id="metal_ins" required>
                                 <option value="Gold">Gold</option>
                                 <?php dropOption($metalins,'Silver'); ?>
                                 <?php dropOption($metalins,'Bronze'); ?>
                                 <?php dropOption($metalins,'Platinum'); ?>
                                 <?php dropOption($metalins,'High'); ?>
                                 <?php dropOption($metalins,'Low'); ?>
                                 <?php dropOption($metalins,'Catastrophic'); ?>
                              </select>
                           </td>
                           <td class="td3">
                              Network Name:<br> <input type="text" name="network_name_ins" value="<?=$plannameins?>" required>
                           </td>
                           <td class="td3">
                              <label for="national_network_ins">National Network:<br>
                              <select name="national_network_ins" id="national_network_ins">
                                 <option value="Yes">Yes</option>
                                 <?php dropOption($nationalnetworkins,'No'); ?>
                              </select>

                           </td>
                        </tr>
                        <tr class="tr3" align="left">
                           <td class="td3">
                             <label for="market_coverage_ins">Market Coverage:<br>
                             <select name="market_coverage_ins" id="market_coverage_ins">
                                <option value="Individual">Individual</option>
                                <?php dropOption($marketins,'Family'); ?>
                                <?php dropOption($marketins,'SHOP (Small Group)'); ?>
                             </select>
                           </td>
                           <td class="td3">
                              Issuer ID:<br> <input type="text" name="issuer_ins" value="<?=$issuerins?>">
                           </td>
                           <td class="td3">
                              <label for="out_country_ins">Out of Country Network:<br>
                              <select name="out_country_ins" id="out_country_ins">
                                 <option value="Yes">Yes</option>
                                 <?php dropOption($outcountryins,'No'); ?>
                              </select>
                           </td>
                           <td class="td3">
                              Zip Codes:<br> <input type="text" name="zip_codes" value="<?=$zipins?>">
                           </td>
                        </tr>
                        <tr class="tr3" align="left">
                           <td class="td3">
                              <label for="dental_ins">Dental Only Plan:<br>
                              <select name="dental_ins" id="dental_ins" required>
                                 <option value="Yes">Yes</option>
                                 <?php dropOption($dentalins,'No'); ?>
                              </select>
                           </td>
                           <td class="td3">
                              Service Area Id:<br> <input type="text" name="area_ins"  value="<?=$areains?>" required>
                           </td>
                        </tr>
                     </table>
                     </br>
                     <table class="table1">
                        <tr class="tr3" align="left">
                           <td class="td3">Enter Benefits Details:</td>
                        </tr>
                        <tr class="tr3" align="left">
                           <td class="td3">
                              Benefit Name:<br> <input type="text" name="ben_name_ins" value="<?=$bennameins?>" required>
                           </td>
                           <td class="td3">
                              Limit Quantity:<br> <input type="text" name="limit_qty_ins" value="<?=$limqtyins?>" required>
                           </td>
                           <td class="td3">
                              Exclusions:<br> <input type="text" name="exclusions_ins" value="<?=$exclusionsins?>" >
                           </td>
                        </tr>
                        <tr class="tr3" align="left">
                           <td class="td3">
                              CoPay:<br> <input type="text" name="copay_ins" value="<?=$copayins?>" required>
                           </td>
                           <td class="td3">
                              LimitUnit:<br> <input type="text" name="lim_unit_ins" value="<?=$limunitins?>" required>
                           </td>
                        </tr>
                     </table>
                     </br>
                     <table class="table1">
                        <tr class="tr3" align="left">
                           <td class="td3">Enter Rate Details:</td>
                        </tr>
                        <tr class="tr3" align="left">
                           <td class="td3">
                              <label for="rate_sub_type_ins">Rate Type:<br>
                              <select name="rate_sub_type_ins" id="rate_sub_type_ins">
                                 <option value="individualrate">Individual</option>
                                 <?php dropOption($ratesubtypeins,'couple','Couple'); ?>
                                 <?php dropOption($ratesubtypeins,'primarysubscriberandonedependent','You and one dependent'); ?>
                                 <?php dropOption($ratesubtypeins,'primarysubscriberandtwodependents','You and two dependents'); ?>
                                 <?php dropOption($ratesubtypeins,'primarysubscriberandthreeormoredependents','You and three or more dependents'); ?>
                                 <?php dropOption($ratesubtypeins,'coupleandonedependent','Couple and one dependent'); ?>
                                 <?php dropOption($ratesubtypeins,'coupleandtwodependents','Couple and two dependents'); ?>
                                 <?php dropOption($ratesubtypeins,'coupleandthreeormoredependents','Couple and three or more dependents'); ?>
                              </select>
                           </td>
                           <td class="td3">
                              <label for="rate_age">Rate Age:<br>
                              <select name="rate_age" id="rate_age">
                                 <option value=""><?=$rateageins?></option>
                                 <?php dropOption($rateageins,'0-20'); ?>
                                 <?php dropOption($rateageins,'21'); ?>
                                 <?php dropOption($rateageins,'22'); ?>
                                 <?php dropOption($rateageins,'23'); ?>
                                 <?php dropOption($rateageins,'24'); ?>
                                 <?php dropOption($rateageins,'25'); ?>
                                 <?php dropOption($rateageins,'26'); ?>
                                 <?php dropOption($rateageins,'27'); ?>
                                 <?php dropOption($rateageins,'28'); ?>
                                 <?php dropOption($rateageins,'29'); ?>
                                 <?php dropOption($rateageins,'30'); ?>
                                 <?php dropOption($rateageins,'31'); ?>
                                 <?php dropOption($rateageins,'32'); ?>
                                 <?php dropOption($rateageins,'33'); ?>
                                 <?php dropOption($rateageins,'34'); ?>
                                 <?php dropOption($rateageins,'35'); ?>
                                 <?php dropOption($rateageins,'36'); ?>
                                 <?php dropOption($rateageins,'37'); ?>
                                 <?php dropOption($rateageins,'38'); ?>
                                 <?php dropOption($rateageins,'39'); ?>
                                 <?php dropOption($rateageins,'40'); ?>
                                 <?php dropOption($rateageins,'41'); ?>
                                 <?php dropOption($rateageins,'42'); ?>
                                 <?php dropOption($rateageins,'43'); ?>
                                 <?php dropOption($rateageins,'44'); ?>
                                 <?php dropOption($rateageins,'45'); ?>
                                 <?php dropOption($rateageins,'46'); ?>
                                 <?php dropOption($rateageins,'47'); ?>
                                 <?php dropOption($rateageins,'48'); ?>
                                 <?php dropOption($rateageins,'49'); ?>
                                 <?php dropOption($rateageins,'50'); ?>
                                 <?php dropOption($rateageins,'51'); ?>
                                 <?php dropOption($rateageins,'52'); ?>
                                 <?php dropOption($rateageins,'53'); ?>
                                 <?php dropOption($rateageins,'54'); ?>
                                 <?php dropOption($rateageins,'55'); ?>
                                 <?php dropOption($rateageins,'56'); ?>
                                 <?php dropOption($rateageins,'57'); ?>
                                 <?php dropOption($rateageins,'58'); ?>
                                 <?php dropOption($rateageins,'59'); ?>
                                 <?php dropOption($rateageins,'60'); ?>
                                 <?php dropOption($rateageins,'61'); ?>
                                 <?php dropOption($rateageins,'62'); ?>
                                 <?php dropOption($rateageins,'63'); ?>
                                 <?php dropOption($rateageins,'64'); ?>
                                 <?php dropOption($rateageins,'65'); ?>
                                 <?php dropOption($rateageins,'65 and over'); ?>
                                 <?php dropOption($rateageins,'Family Option'); ?>
                              </select>
                           </td>
                           <td class="td3">
                              Rate:<br> <input type="text" name="rate_ins" value="<?=$rateins?>" required>
                           </td>
                        </tr>
                     </table>
                     <br>
                     <!--button type="button" onclick="alert('You pressed the button!')">Create Plan</button-->
                     <input type="submit" name="CreatePlan" id="CreatePlan" value="Create Plan" /><br/>
                  </form>
                  <?php
                     ///////////////////////////////
                     // THIS IS FOR CREATE PLAN BUTTON
                     ///////////////////////////////
                     if(isset($_GET['CreatePlan'])){ //check if form was submitted
                       // insert into plans
                         // PlanId,PlanMarketingName,PlanType,MarketCoverage,DentalOnlyPlan,DiseasesCovered,
                       // DrugDeductibles,MetalLevel,PlanBrochure,EnrollmentURL,BenefitsCoverageURL,NetworkId,ServiceAreaId

                       $insertQuery = "insert into public.factplanattributes (
                         plan_key,
                         area_key,
                         component_key,
                         network_key,
                         plan_code,
                         area_code,
                         component_code,
                         network_code,";

                       $valuesQuery = "values (
                         CAST(encode(digest(CAST(2016 AS text) || '|' || '$planidins' || '|' || CAST(1 AS text),'SHA256'),'hex') as text),
                         CAST(encode(digest(CAST(2016 AS text) || '|' || CAST('$issuerins' AS text) || '|' || '$areains' || '|' || CAST(1 AS text) || '|' || '$marketins' || '|' || '$dentalins','sha256'),'hex') AS TEXT),
                         CAST(encode(digest(CAST(2016 AS text) || '|' || '$planidins' || '|' || CAST(1 AS text),'SHA256'),'hex') AS text),
                         CAST(encode(digest(CAST(2016 AS text) || '|' || CAST('$issuerins' AS text) || '|' || '$networkins' || '|' || CAST(1 AS text) || '|' || '$marketins' || '|' || '$dentalins','SHA256'),'hex') AS TEXT),
                         CAST(2016 AS text) || '|' || '$planidins' || '|' || CAST(1 AS text),
                         CAST(2016 AS text) || '|' || CAST('$issuerins' AS text) || '|' || '$areains' || '|' || CAST(1 AS text) || '|' || '$marketins' || '|' || '$dentalins',
                         CAST(2016 AS text) || '|' || '$planidins' || '|' || CAST(1 AS text),
                         CAST(2016 AS text) || '|' || CAST('$issuerins' AS text) || '|' || '$networkins' || '|' || CAST(1 AS text) || '|' || '$marketins' || '|' || '$dentalins',";

                       if(isset($_GET['plan_id_ins'])){
                         $insertQuery .= "planid,";
                         $valuesQuery .= "'" . $_GET['plan_id_ins']."',";
                       }
                       if(isset($_GET['issuer_ins'])){
                         $insertQuery .= "issuerid,";
                         $valuesQuery .= "'" . $_GET['issuer_ins']."',";
                       }
                       if(isset($_GET['area_ins'])){
                         $insertQuery .= "serviceareaid,";
                         $valuesQuery .= "'" . $_GET['area_ins']."',";
                       }
                       if(isset($_GET['network_ins'])){
                         $insertQuery .= "networkid,";
                         $valuesQuery .= "'" . $_GET['network_ins']."',";
                       }
                       if(isset($_GET['market_coverage_ins'])){
                         $insertQuery .= "MarketCoverage,";
                         $valuesQuery .= "'" . $_GET['market_coverage_ins']."',";
                       }
                       if(isset($_GET['dental_ins'])){
                         $insertQuery .= "DentalOnlyPlan,";
                         $valuesQuery .= "'" . $_GET['dental_ins']."',";
                       }
                       if(isset($_GET['benefit_url_ins'])){
                         $insertQuery .= "urlforsummaryofbenefitscoverage,";
                         $valuesQuery .= "'" . $_GET['benefit_url_ins']."',";
                       }
                       if(isset($_GET['state_ins'])){
                         $insertQuery .= "statecode,";
                         $valuesQuery .= "'" . $_GET['state_ins']."',";
                       }
                       if(isset($_GET['is_hsa_ins'])){
                         $insertQuery .= "ishsaeligible,";
                         $valuesQuery .= "'" . $_GET['is_hsa_ins']."',";
                       }
                       if(isset($_GET['disease_ins'])){
                         $insertQuery .= "diseasemanagementprogramsoffered,";
                         $valuesQuery .= "'" . $_GET['disease_ins']."',";
                       }
                       if(isset($_GET['metal_ins'])){
                         $insertQuery .= "metallevel,";
                         $valuesQuery .= "'" . $_GET['metal_ins']."',";
                       }
                       if(isset($_GET['out_country_ins'])){
                         $insertQuery .= "outofcountrycoverage,";
                         $valuesQuery .= "'" . $_GET['out_country_ins']."',";
                       }
                       if(isset($_GET['national_network_ins'])){
                         $insertQuery .= "nationalnetwork,";
                         $valuesQuery .= "'" . $_GET['national_network_ins']."',";
                       }
                       if(isset($_GET['plan_name_ins'])){
                         $insertQuery .= "planmarketingname,";
                         $valuesQuery .= "'" . $_GET['plan_name_ins']."',";
                       }
                       if(isset($_GET['plan_type_ins'])){
                         $insertQuery .= "plantype,";
                         $valuesQuery .= "'" . $_GET['plan_type_ins']."',";
                       }


                       $insertQuery = substr($insertQuery, 0, -1);
                       $valuesQuery = substr($valuesQuery, 0, -1);
                       $insertQuery .= ") ";
                       $valuesQuery .= ");";
                       $insertQuery .= $valuesQuery;

                       //echo("<p> $insertQuery </p?");

                     	$result = pg_query($connection, $insertQuery);
                     	pg_free_result($result);

                      // insert into benefits
                    //PlanId,BenefitName,CoPay,LimitQty,LimitUnit,Exclusions
                    $insertQuery = "insert into public.dimbenefitscostsharing(
                      plan_key,
                      plan_code,";

                    $valuesQuery = "values (
                      CAST(encode(digest(CAST(2016 AS text) || '|' || '$planidins' || '|' || CAST(1 AS text),'SHA256'),'hex') as text),
                      CAST(2016 AS text) || '|' || '$planidins' || '|' || CAST(1 AS text),";

                      if(isset($_GET['ben_name_ins'])){
                        $insertQuery .= "benefitname,";
                        $valuesQuery .= "'" . $_GET['ben_name_ins']."',";
                      }
                      if(isset($_GET['limit_qty_ins'])){
                        $insertQuery .= "limitqty,";
                        $valuesQuery .= "'" . $_GET['limit_qty_ins']."',";
                      }
                      if(isset($_GET['lim_unit_ins'])){
                        $insertQuery .= "limitunit,";
                        $valuesQuery .= "'" . $_GET['lim_unit_ins']."',";
                      }
                      if(isset($_GET['exclusions_ins'])){
                        $insertQuery .= "exclusions,";
                        $valuesQuery .= "'" . $_GET['exclusions_ins']."',";
                      }
                      if(isset($_GET['copay_ins'])){
                        $insertQuery .= "copayinntier1,";
                        $valuesQuery .= "'" . $_GET['copay_ins']."',";
                      }
                      if(isset($_GET['plan_id_ins'])){
                        $insertQuery .= "planid,";
                        $valuesQuery .= "'" . $_GET['plan_id_ins']."',";
                      }

                      $insertQuery = substr($insertQuery, 0, -1);
                      $valuesQuery = substr($valuesQuery, 0, -1);
                      $insertQuery .= ") ";
                      $valuesQuery .= ");";
                      $insertQuery .= $valuesQuery;

                     $result = pg_query($connection, $insertQuery);
                     pg_free_result($result);


                     $insertQuery = "insert into public.dimrate(
                       component_key,
                       component_code,";

                     $valuesQuery = "values (
                       CAST(encode(digest(CAST(2016 AS text) || '|' || '$planidins' || '|' || CAST(1 AS text),'SHA256'),'hex') AS text),
                       CAST(2016 AS text) || '|' || '$planidins' || '|' || CAST(1 AS text),";

                       if(isset($_GET['rate_age'])){
                         $insertQuery .= "age,";
                         $valuesQuery .= "'" . $_GET['rate_age']."',";
                       }
                       if(isset($_GET['rate_ins'])){
                         $insertQuery .= "$ratesubtypeins,";
                         $valuesQuery .= "'" . $_GET['rate_ins']."',";
                       }
                       if(isset($_GET['state_ins'])){
                         $insertQuery .= "statecode,";
                         $valuesQuery .= "'" . $_GET['state_ins']."',";
                       }
                       if(isset($_GET['plan_id_ins'])){
                         $insertQuery .= "planid,";
                         $valuesQuery .= "'" . $_GET['plan_id_ins']."',";
                       }

                       $insertQuery = substr($insertQuery, 0, -1);
                       $valuesQuery = substr($valuesQuery, 0, -1);
                       $insertQuery .= ") ";
                       $valuesQuery .= ");";
                       $insertQuery .= $valuesQuery;

                      $result = pg_query($connection, $insertQuery);
                      pg_free_result($result);


 /*
                       // insert into subject area
                     //  ServiceAreaId,StateCode,ServiceAreaName,CoverEntireState,ZipCodes
                       $insertQuery = "insert into public.servicearea ( ServiceAreaId,StateCode,ServiceAreaName,CoverEntireState,ZipCodes) values ('";
                     	$insertQuery .= $_GET['ServiceAreaId']."','";
                     	$insertQuery .= $_GET['StateCode']."','";
                     	$insertQuery .= $_GET['ServiceAreaName']."','";
                     	$insertQuery .= $_GET['CoverEntireState']."','";
                     	$insertQuery .= $_GET['ZipCodes']."');";


                     	$result = pg_query($connection, $insertQuery);
                     	pg_free_result($result);


                       // insert into network
                       //NetworkId,NetworkName,NetworkURL
                       $insertQuery = "insert into public.network ( NetworkId,NetworkName,NetworkURL) values ('";
                     	$insertQuery .= $_GET['NetworkId']."','";
                     	$insertQuery .= $_GET['NetworkName']."','";
                     	$insertQuery .= $_GET['NetworkURL']."');";


                     	$result = pg_query($connection, $insertQuery);
                     	pg_free_result($result);


                       // insert into rates
                     //PlanId,RateType,RateSubType,Rate
                       $insertQuery = "insert into public.rates ( PlanId,RateType,RateSubType,Rate) values ('";
                     	$insertQuery .= $_GET['PlanId']."','";
                     	$insertQuery .= $_GET['RateType']."','";
                     	$insertQuery .= $_GET['RateSubType']."','";
                     	$insertQuery .= $_GET['Rate']."');";


                     	$result = pg_query($connection, $insertQuery);
                     	pg_free_result($result);






*/
                     	echo "<script type='text/javascript'>alert('Record Created Successfully');</script>";


                     	// Free resultset
                     	pg_free_result($result);

                     	// Closing connection
                     	//pg_close($connection);

                     }
                     ?>
               </section>
               <section id="section-shape-3">


                  <table class="table1">
                     <tr class="tr1" align="left">
                        <td class="td1">Enter Your Details</td>
                     </tr>
                     <form >
                        <tr class="tr3" align="left">
                           <td class="td3">
                              <label for="plan_type_ml">Plan Type:<br>
                              <select name="plan_type_ml" id="plan_type_ml">
                                 <option value="">Select</option>
                                 <?php dropOption($plan_type_ml,'PPO'); ?>
                                 <?php dropOption($plan_type_ml,'EPO'); ?>
                                 <?php dropOption($plan_type_ml,'POS'); ?>
                                 <?php dropOption($plan_type_ml,'HMO'); ?>
                                 <?php dropOption($plan_type_ml,'Indemnity'); ?>
                              </select>
                           </td>
                           <td class="td3">
                              <label for="dental_only_plan_ml">Dental Only Plan:<br>
                              <select name="dental_only_plan_ml" id="dental_only_plan_ml">
                                 <option value="">Select</option>
                                 <?php dropOption($dental_only_plan_ml,'Yes'); ?>
                                 <?php dropOption($dental_only_plan_ml,'No'); ?>
                              </select>
                           </td>
                           <td class="td3">
                              <label for="markge_coverage_ml">Market Coverage:<br>
                              <select name="markge_coverage_ml" id="markge_coverage_ml">
                                 <option value="">Select</option>
                                 <?php dropOption($markge_coverage_ml,'Individual'); ?>
                                 <?php dropOption($markge_coverage_ml,'SHOP (Small Group)'); ?>
                              </select>
                           </td>
                        </tr>
                        <tr class="tr3" align="left">
                           <td class="td3">
                              <label for="out_of_country_ml">Out of Country Coverage:<br>
                              <select name="out_of_country_ml" id="out_of_country_ml">
                                 <option value="">Select</option>
                                 <?php dropOption($out_of_country_ml,'Yes'); ?>
                                 <?php dropOption($out_of_country_ml,'No'); ?>
                              </select>
                           </td>
                           <td class="td3">
                              <label for="age_ml">Age:<br>
                              <select name="age_ml" id="age_ml">
                                 <option value="">Select</option>
                                 <?php dropOption($age_ml,'0-20'); ?>
                                 <?php dropOption($age_ml,'21'); ?>
                                 <?php dropOption($age_ml,'22'); ?>
                                 <?php dropOption($age_ml,'23'); ?>
                                 <?php dropOption($age_ml,'24'); ?>
                                 <?php dropOption($age_ml,'25'); ?>
                                 <?php dropOption($age_ml,'26'); ?>
                                 <?php dropOption($age_ml,'27'); ?>
                                 <?php dropOption($age_ml,'28'); ?>
                                 <?php dropOption($age_ml,'29'); ?>
                                 <?php dropOption($age_ml,'30'); ?>
                                 <?php dropOption($age_ml,'31'); ?>
                                 <?php dropOption($age_ml,'32'); ?>
                                 <?php dropOption($age_ml,'33'); ?>
                                 <?php dropOption($age_ml,'34'); ?>
                                 <?php dropOption($age_ml,'35'); ?>
                                 <?php dropOption($age_ml,'36'); ?>
                                 <?php dropOption($age_ml,'37'); ?>
                                 <?php dropOption($age_ml,'38'); ?>
                                 <?php dropOption($age_ml,'39'); ?>
                                 <?php dropOption($age_ml,'40'); ?>
                                 <?php dropOption($age_ml,'41'); ?>
                                 <?php dropOption($age_ml,'42'); ?>
                                 <?php dropOption($age_ml,'43'); ?>
                                 <?php dropOption($age_ml,'44'); ?>
                                 <?php dropOption($age_ml,'45'); ?>
                                 <?php dropOption($age_ml,'46'); ?>
                                 <?php dropOption($age_ml,'47'); ?>
                                 <?php dropOption($age_ml,'48'); ?>
                                 <?php dropOption($age_ml,'49'); ?>
                                 <?php dropOption($age_ml,'50'); ?>
                                 <?php dropOption($age_ml,'51'); ?>
                                 <?php dropOption($age_ml,'52'); ?>
                                 <?php dropOption($age_ml,'53'); ?>
                                 <?php dropOption($age_ml,'54'); ?>
                                 <?php dropOption($age_ml,'55'); ?>
                                 <?php dropOption($age_ml,'56'); ?>
                                 <?php dropOption($age_ml,'57'); ?>
                                 <?php dropOption($age_ml,'58'); ?>
                                 <?php dropOption($age_ml,'59'); ?>
                                 <?php dropOption($age_ml,'60'); ?>
                                 <?php dropOption($age_ml,'61'); ?>
                                 <?php dropOption($age_ml,'62'); ?>
                                 <?php dropOption($age_ml,'63'); ?>
                                 <?php dropOption($age_ml,'64'); ?>
                                 <?php dropOption($age_ml,'65'); ?>
                                 <?php dropOption($age_ml,'65 and over'); ?>
                                 <?php dropOption($age_ml,'Family Option'); ?>
                              </select>
                           </td>
                           <td class="td3">
                              <label for="metal_level_ml">Metal Level:<br>
                              <select name="metal_level_ml" id="metal_level_ml">
                                 <option value="">Select</option>
                                 <?php dropOption($metal_level_ml,'High'); ?>
                                 <?php dropOption($metal_level_ml,'Low'); ?>
                                 <?php dropOption($metal_level_ml,'Gold'); ?>
                                 <?php dropOption($metal_level_ml,'Silver'); ?>
                                 <?php dropOption($metal_level_ml,'Bronze'); ?>
                                 <?php dropOption($metal_level_ml,'Platinum'); ?>
                                 <?php dropOption($metal_level_ml,'Catastrophic'); ?>
                              </select>
                           </td>
                        </tr>
                        <tr class="tr3" align="left">
                           <td class="td3">
                              <label for="out_of_service_area_ml">Out of Service Area Coverage:<br>
                              <select name="out_of_service_area_ml" id="out_of_service_area_ml">
                                 <option value="">Select</option>
                                 <?php dropOption($out_of_service_area_ml,'Yes'); ?>
                                 <?php dropOption($out_of_service_area_ml,'No'); ?>
                              </select>
                           </td>
                           <td class="td3">
                              <label for="state_ml">State: <br>
                              <select name="state_ml" id="state_ml">
                                 <option value="">Select</option>
                                 <?php dropOption($state_ml,'AK'); ?>
                                 <?php dropOption($state_ml,'AL'); ?>
                                 <?php dropOption($state_ml,'AR'); ?>
                                 <?php dropOption($state_ml,'AZ'); ?>
                                 <?php dropOption($state_ml,'DE'); ?>
                                 <?php dropOption($state_ml,'FL'); ?>
                                 <?php dropOption($state_ml,'GA'); ?>
                                 <?php dropOption($state_ml,'HI'); ?>
                                 <?php dropOption($state_ml,'IA'); ?>
                                 <?php dropOption($state_ml,'IL'); ?>
                                 <?php dropOption($state_ml,'IN'); ?>
                                 <?php dropOption($state_ml,'KS'); ?>
                                 <?php dropOption($state_ml,'LA'); ?>
                                 <?php dropOption($state_ml,'ME'); ?>
                                 <?php dropOption($state_ml,'MI'); ?>
                                 <?php dropOption($state_ml,'MO'); ?>
                                 <?php dropOption($state_ml,'MS'); ?>
                                 <?php dropOption($state_ml,'MT'); ?>
                                 <?php dropOption($state_ml,'NC'); ?>
                                 <?php dropOption($state_ml,'ND'); ?>
                                 <?php dropOption($state_ml,'NE'); ?>
                                 <?php dropOption($state_ml,'NH'); ?>
                                 <?php dropOption($state_ml,'NJ'); ?>
                                 <?php dropOption($state_ml,'NM'); ?>
                                 <?php dropOption($state_ml,'NV'); ?>
                                 <?php dropOption($state_ml,'OH'); ?>
                                 <?php dropOption($state_ml,'OK'); ?>
                                 <?php dropOption($state_ml,'OR'); ?>
                                 <?php dropOption($state_ml,'PA'); ?>
                                 <?php dropOption($state_ml,'SC'); ?>
                                 <?php dropOption($state_ml,'SD'); ?>
                                 <?php dropOption($state_ml,'TN'); ?>
                                 <?php dropOption($state_ml,'TX'); ?>
                                 <?php dropOption($state_ml,'UT'); ?>
                                 <?php dropOption($state_ml,'VA'); ?>
                                 <?php dropOption($state_ml,'WI'); ?>
                                 <?php dropOption($state_ml,'WV'); ?>
                                 <?php dropOption($state_ml,'WY'); ?>
                              </select>
                           </td>
                           <td class="td3">
                              <label for="tobacco_ml">Tobacco Usage:<br>
                              <select name="tobacco_ml" id="tobacco_ml">
                                 <option value="">Select</option>
                                 <?php dropOption($tobacco_ml,'Tobacco-User'); ?>
                                 <?php dropOption($tobacco_ml,'Non-Tobacco-User'); ?>
                              </select>
                           </td>
                        </tr>

                        <tr class="tr3" align="center">
                           <td class="td3"></td>
                           <td class="td3">
                              <input type="submit" name="GetQuoteButton" id="GetQuoteButton" value="GetQuote" /><br/>
                           </td>
                           <td class="td3"></td>
                        </tr>
                     </form>
                  </table>


                  </br>
                  <table class="table1">
                     <tr class="tr1" align="left">
                        <td class="td1">Here's the best quote(s) for you</td>
                     </tr>
                  </table>


                  <table class="table2" >
					<tr class="tr1" align="left">
						<td class="td1">
						 <?php
							if(isset($_GET['GetQuoteButton'])){

							   //$command = escapeshellcmd("python get_quote.py $plan_type_ml");
							   //$command = "python get_quote.py $plan_type_ml";
							   //echo $command;
							   //$output = shell_exec($command);
							   //$output = passthru("python get_quote.py $plan_type_ml");
							   $output = shell_exec("/var/www/html/CS411FinalProject/get_quote.py $plan_type_ml $dental_only_plan_ml $markge_coverage_ml $metal_level_ml $out_of_country_ml $state_ml $out_of_service_area_ml $tobacco_ml $age_ml");
							   echo $output;
							   //$_GET['GetQuoteButton']=null;
							}
							?>
						</td>
					</tr>
                  </table>





               </section>
               <section id="section-shape-4">
			   <div align="left">
			   <div align="left">&nbsp;&nbsp;&nbsp;<strong>State Vs Average Premium Price</strong></div>
			   <div class="vizdropdown" align="left">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Compare average premium price across states</div>
			   <div class="vizdropdown" align="right">&nbsp;&nbsp;&nbsp;Select Coverage Type:</div>
					<div class="vizdropdown" id="drop" align="right"></div>

	<div id="visualContainer" align="left">
		<svg class="viz1" id = "viz1" width="700" height="520"></svg>
	</div>

					<script src="http://d3js.org/d3.v3.min.js"></script>
					<script type="text/javascript">

					//{top: 80, right: 180, bottom: 80, left: 180}
					// - margin.left - margin.right
var margin = {top: 20, right: 10, bottom: 80, left: 40},
    width = 670 - margin.left - margin.right,
    height = 450 - margin.top - margin.bottom;

var svg = d3.select(".viz1").append("svg")
	.attr("width", width + margin.left + margin.right)
    .attr("height", height + margin.top + margin.bottom)
	.append("g")
    .attr("transform", "translate(" + margin.left + "," + margin.top + ")")

	;

d3.tsv("rates_viz.tsv", function(error, data){

	// filter year
	// var data = data.filter(function(d){return d.Year == '2012';});
	// Get every column value
	var elements = Object.keys(data[0])
		.filter(function(d){
			return (d != "State");
		});

	var selection = elements[0];

	var y = d3.scale.linear()
			.domain([0, d3.max(data, function(d){
				return +d[selection];
			})])
			.range([height, 0]);

	var x = d3.scale.ordinal()
			.domain(data.map(function(d){ return d.State;}))
			.rangeBands([0, width]);


	var xAxis = d3.svg.axis()
		.scale(x)
	    .orient("bottom");

	var dollarFormat = function(d) { return '$' + d3.format(',f')(d) };
	var yAxis = d3.svg.axis()
		.scale(y)
		.tickFormat(dollarFormat)
	    .orient("left");

	svg.append("g")
    	.attr("class", "x axis")
    	.attr("transform", "translate(0," + height + ")")
    	.call(xAxis)
		//.tickFormat(d3.formatPrefix(".1", 1e6)))
    	.selectAll("text")
    	.style("font-size", "11px")
      	.style("text-anchor", "end")
      	.attr("dx", "-.8em")
      	.attr("dy", "-.55em")
      	.attr("transform", "rotate(-90)" );


 	svg.append("g")
    	.attr("class", "y axis")
    	.call(yAxis)
		.style("font-size", "12px")
      	;

	svg.selectAll("rectangle")
		.data(data)
		.enter()
		.append("rect")
		.attr("class","rectangle")
		.attr("stroke","white")
		//.attr("stroke-width","1%")
		.attr("width", (width/data.length))
		.attr("height", function(d){
			return height - y(+d[selection]);
		})
		.attr("x", function(d, i){
			return ((width / data.length)) * i ;
		})
		.attr("y", function(d){
			return y(+d[selection]);
		})
		.append("title")
		.text(function(d){
			return d.State + " : " + d[selection];
		});

	var formatDecimal  = d3.format(".2f");
	var selector = d3.select("#drop")
    	.append("select")
		//.text("xxx")
    	.attr("id","dropdown")
    	.on("change", function(d){
        	selection = document.getElementById("dropdown");

        	y.domain([0, d3.max(data, function(d){
				return +d[selection.value];})]);

        	yAxis.scale(y);

        	d3.selectAll(".rectangle")
           		.transition()
	            .attr("height", function(d){
					return height - y(+d[selection.value]);
				})
				.attr("x", function(d, i){
					return (width / data.length) * i ;
				})
				.attr("y", function(d){
					return y(+d[selection.value]);
				})
           		.ease("linear")
           		.select("title")
           		.text(function(d){
           			return d.State + " : $" + formatDecimal(d[selection.value]);
           		});

           	d3.selectAll("g.y.axis")
           		.transition()
           		.call(yAxis);

         });

    selector.selectAll("option")
      .data(elements)
      .enter().append("option")
      .attr("value", function(d){
        return d;
      })
      .text(function(d){
        return d;
      })


});






					</script>


</div>

               </section>
               <section id="section-shape-5">
                  <div align="left">
                     <strong>Welcome to US Health Insurance Marketplace</strong>
                     </br>
                     <ul style="list-style-type:disc;" font-weight=200>
                        <li>Use <em><b>"Search"</b></em> tab to search and view plans and also edit them. </li>
                        </br>
                        <li>Use <em><b>"Create"</b></em> tab to create new plans. </li>
                        </br>
                        <li>Use <em><b>"Get Quote"</b></em> tab to enter your details and get a suitable quote. </li>
                        </br>
                        <li>Use <em><b>"Analytics"</b></em> tab to view various insightful analytical reports on insurance plans. </li>
                     </ul>
                     <!--font size="3" color="red">Note: </font-->
                     <!--font size="3" >
                        <ul >
                           <li>Currently anyone can create and edit plans, feature to enable this only for admin users is work-in-progress. </li>
                           <li><em>"Analytics"</em> and <em>"Get Quote"</em> tabs are work-in-progress</li>
                        </ul>
                     </font-->
                  </div>
               </section>
            </div>
         </div>
      </section>
      <script src="js/cbpFWTabs.js"></script>
      <script>
         (function() {

         	[].slice.call( document.querySelectorAll( '.tabs' ) ).forEach( function( el ) {
         		new CBPFWTabs( el );
         	});

         })();
      </script>

   </body>
</html>
