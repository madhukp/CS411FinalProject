#!/usr/bin/env python

import sys
#print(sys.argv)
# coding: utf-8

# In[1]:

import numpy as np
import pandas as pd
import warnings
warnings.filterwarnings('ignore')


# In[2]:

def ts(x):
    print(type(x))
    print(np.shape(x))


# In[3]:

fmly_plans = pd.read_csv(r'/var/www/html/CS411FinalProject/mlGetQuoteFiles/prepped_fmly.txt', sep = '\t')
indv_plans = pd.read_csv(r'/var/www/html/CS411FinalProject/mlGetQuoteFiles/prepped_indv.txt', sep = '\t')


# In[4]:

x_columns = ['PlanType','DentalOnlyPlan','MarketCoverage','MetalLevel','OutOfCountryCoverage',
             'StateCode','OutOfServiceAreaCoverage','Tobacco','Age']
fmly_plans_x = fmly_plans[x_columns]
indv_plans_x = indv_plans[x_columns]

# In[5]:

Couple_y  = fmly_plans["Couple"]
PrimarySubscriberAndOneDependent_y  = fmly_plans["PrimarySubscriberAndOneDependent"]
PrimarySubscriberAndTwoDependents_y  = fmly_plans["PrimarySubscriberAndTwoDependents"]
PrimarySubscriberAndThreeOrMoreDependents_y  = fmly_plans["PrimarySubscriberAndThreeOrMoreDependents"]
CoupleAndOneDependent_y  = fmly_plans["CoupleAndOneDependent"]
CoupleAndTwoDependents_y  = fmly_plans["CoupleAndTwoDependents"]
CoupleAndThreeOrMoreDependents_y  = fmly_plans["CoupleAndThreeOrMoreDependents"]
IndividualRate_y = indv_plans["IndividualRate"]


# In[6]:

from sklearn import preprocessing


# In[7]:

label_encoder_lst = []
encoded_fmly_data = fmly_plans_x.copy()
encoded_indv_data = indv_plans_x.copy()



for col in x_columns:
    le = preprocessing.LabelEncoder()
    le.fit(fmly_plans_x[col].append(indv_plans_x[col]))
    label_encoder_lst.append(le)
    encoded_fmly_data[col] = le.transform(fmly_plans_x[col])
    encoded_indv_data[col] = le.transform(indv_plans_x[col])


# In[8]:

from sklearn.externals import joblib
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error


# In[9]:

def train_test_model(X, y, yNname):
    reg = LinearRegression()
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)
    reg.fit(X_train, y_train)
    
    #print("----------------------------------------")
    #print("Rate for {}".format(yNname))
    #print("Training MSE: {}".format(mean_squared_error(y_train, reg.predict(X_train))))
    #print("Testing  MSE: {}".format(mean_squared_error(y_test, reg.predict(X_test))))
    
    joblib.dump(reg, r'/var/www/html/CS411FinalProject/mlGetQuoteFiles/'+yNname + '.pkl')

# In[19]:

#import os
train_ind_exists = True#os.path.isfile(r'/var/www/html/CS411FinalProject/mlGetQuoteFiles/yes_train_the_model.txt')
if train_ind_exists:
    train_test_model(encoded_fmly_data, Couple_y, 'Couple')
    train_test_model(encoded_fmly_data, PrimarySubscriberAndOneDependent_y, 'PrimarySubscriberAndOneDependent')
    train_test_model(encoded_fmly_data, PrimarySubscriberAndTwoDependents_y, 'PrimarySubscriberAndTwoDependents')
    train_test_model(encoded_fmly_data, PrimarySubscriberAndThreeOrMoreDependents_y, 'PrimarySubscriberAndThreeOrMoreDependents')
    train_test_model(encoded_fmly_data, CoupleAndOneDependent_y, 'CoupleAndOneDependent')
    train_test_model(encoded_fmly_data, CoupleAndTwoDependents_y, 'CoupleAndTwoDependents')
    train_test_model(encoded_fmly_data, CoupleAndThreeOrMoreDependents_y, 'CoupleAndThreeOrMoreDependents')
    train_test_model(encoded_indv_data, IndividualRate_y, 'IndividualRate')


# In[11]:

y_lst = ['IndividualRate', 'Couple', 'PrimarySubscriberAndOneDependent', 'PrimarySubscriberAndTwoDependents', 
         'PrimarySubscriberAndThreeOrMoreDependents', 'CoupleAndOneDependent', 
         'CoupleAndTwoDependents', 'CoupleAndThreeOrMoreDependents']
y_lst_desc = ['Individual', 'Couple', 'Primary Subscriber And One Dependent', 'Primary Subscriber And Two Dependents',
              'Primary Subscriber And Three Or More Dependents', 'Couple And One Dependent', 
              'Couple And Two Dependents', 'Couple And Three Or More Dependents']


# In[12]:

def get_quote(X, yNname):
    reg = joblib.load(r'/var/www/html/CS411FinalProject/mlGetQuoteFiles/'+yNname+'.pkl')
    return abs(reg.predict(X))


# In[13]:
import sys
'''
print "This is the name of the script: ", sys.argv[0]
print "Number of arguments: ", len(sys.argv)
print "The arguments are: " , str(sys.argv)
'''

'''
ip_PlanType = 'PPO'
ip_DentalOnlyPlan = 'Yes'
ip_MarketCoverage = 'Individual'
ip_MetalLevel = 'High'
ip_OutOfCountryCoverage = 'No'
ip_StateCode = 'NJ'
ip_OutOfServiceAreaCoverage = 'Yes'
ip_Tobacco = 'Tobacco-User'
ip_Age = '30'
'''

ip_PlanType = sys.argv[1]
ip_DentalOnlyPlan = sys.argv[2]
ip_MarketCoverage = sys.argv[3]
ip_MetalLevel = sys.argv[4]
ip_OutOfCountryCoverage = sys.argv[5]
ip_StateCode = sys.argv[6]
ip_OutOfServiceAreaCoverage = sys.argv[7]
ip_Tobacco = sys.argv[8]
ip_Age = sys.argv[9]

# In[14]:
#print(ip_PlanType)

input_x = pd.DataFrame([[ip_PlanType, ip_DentalOnlyPlan, ip_MarketCoverage, ip_MetalLevel, ip_OutOfCountryCoverage, 
                         ip_StateCode, ip_OutOfServiceAreaCoverage, ip_Tobacco, ip_Age]])
input_x_encoded = input_x.copy()
for i in input_x.columns:
    input_x_encoded[i] = label_encoder_lst[i].transform(input_x[i])


# In[15]:

for i in range(len(y_lst)):
    print("<strong><font size='+2'>Quote for {:47} - </font><font color=\"#0dc114\" size='+2'>${:.2f}</font></strong>".format(y_lst_desc[i], get_quote(input_x_encoded,y_lst[i])[0]  ))
    print("<br>")
    #break

# In[ ]:




# In[ ]:



