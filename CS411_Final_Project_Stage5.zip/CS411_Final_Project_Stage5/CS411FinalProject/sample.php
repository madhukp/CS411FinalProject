<?php include "../../inc/dbinfo.inc"; ?>
<html>
<body>
<h1>Sample page</h1>
<?php

  //echo "<h1> Inside PHP </h1>";
  $conn_string = "host=" . DB_SERVER . " port=" . DB_PORT . " dbname=" . DB_DATABASE . " user=" . DB_USERNAME . " password=" . DB_PASSWORD . " connect_timeout=5";
  //echo "<p> " . $conn_string . " </p>"; 
  $connection = pg_connect($conn_string) or die('Could not connect: ' . pg_last_error());
  //echo "<p> connection attempt made </p>";
  if (!$connection) {
    echo "<p> An error occurred connecting to the database </p>";
    exit;
  }

?>


<!-- Display table data. -->
<table border="1" cellpadding="2" cellspacing="2">
  <tr>
    <td>PlanType</td>
    <td>NationalNetwork</td>
    <td>MaxOutOfPocket</td>
  </tr>

<?php

$result = pg_query($connection, "SELECT plantype, nationalnetwork, mehbcombinnoonfamilypergroupmoop
FROM public.factplanattributes
where businessyear = 2016 and mehbcombinnoonfamilypergroupmoop is not null
LIMIT 10;"); 

	if (!$result) {
	  echo "<h1> An error occurred selecting data from the database </h1>";
	  exit;
	}
	
while($query_data = pg_fetch_row($result)) {
  echo "<tr>";
  echo "<td>",$query_data[0], "</td>",
       "<td>",$query_data[1], "</td>",
       "<td>",$query_data[2], "</td>";
  echo "</tr>";
}
?>

</table>

<!-- Clean up. -->
<?php

// Free resultset
pg_free_result($result);

// Closing connection
pg_close($connection);

?>

</body>
</html>


