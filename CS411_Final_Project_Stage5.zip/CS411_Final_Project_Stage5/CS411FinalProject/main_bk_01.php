
<?php include "../../inc/dbinfo.inc"; ?>
<?php

  //echo "<h1> Inside PHP </h1>";
  $conn_string = "host=" . DB_SERVER . " port=" . DB_PORT . " dbname=" . DB_DATABASE . " user=" . DB_USERNAME . " password=" . DB_PASSWORD . " connect_timeout=5";
  //echo "<p> " . $conn_string . " </p>";
  $connection = pg_connect($conn_string) or die('Could not connect: ' . pg_last_error());
  //echo "<p> connection attempt made </p>";
  if (!$connection) {
    echo "<p> An error occurred connecting to the database </p>";
    exit;
  }

?>

<!DOCTYPE html>
<html lang="en" class="no-js">
	<head>
		<meta charset="UTF-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>US Health Insurance</title>
		<meta name="description" content="US Health Insurance MarketPlace" />
		<meta name="keywords" content="US Health Insurance MarketPlace" />
		<meta name="author" content="CS411-Team-Rigel" />
		<link rel="shortcut icon" href="../favicon.ico">
		<link rel="stylesheet" type="text/css" href="css/normalize.css" />
		<link rel="stylesheet" type="text/css" href="css/demo.css" />
		<link rel="stylesheet" type="text/css" href="css/tabs.css" />
		<link rel="stylesheet" type="text/css" href="css/tabstyles.css" />
  		<script src="js/modernizr.custom.js"></script>
	</head>

    <style type="text/css">
      .displayNone { display: none; }
    </style>



	<body>
		<svg class="hidden">
			<defs>
				<path id="tabshape" d="M80,60C34,53.5,64.417,0,0,0v60H80z"/>
			</defs>
		</svg>
		<div class="container">
			<!-- Top Navigation -->
			<div class="codrops-top clearfix">
				<!--a class="codrops-icon codrops-icon-prev" href=""><span>Previous Demo</span></a-->
				<a class="codrops-icon codrops-icon-drop" href=""><span>Login as Admin</span></a>
				<span class="right"><a class="codrops-icon codrops-icon-drop" href=""><span>About US</span></a></span>
			</div>
			<!--header class="codrops-header">
				<h1>Tab Styles Inspiration <span>A small collection of styles for tabs</span></h1>

			</header-->

			<section>
				<div class="tabs tabs-style-shape">
					<nav>
						<ul>
							<li>
								<a href="#section-shape-1">
									<svg viewBox="0 0 80 60" preserveAspectRatio="none"><use xlink:href="#tabshape"></use></svg>
									<span>Search</span>
								</a>
							</li>
							<li>
								<a href="#section-shape-2">
									<svg viewBox="0 0 80 60" preserveAspectRatio="none"><use xlink:href="#tabshape"></use></svg>
									<svg viewBox="0 0 80 60" preserveAspectRatio="none"><use xlink:href="#tabshape"></use></svg>
									<span>Create</span>
								</a>
							</li>
							<li>
								<a href="#section-shape-3">
									<svg viewBox="0 0 80 60" preserveAspectRatio="none"><use xlink:href="#tabshape"></use></svg>
									<svg viewBox="0 0 80 60" preserveAspectRatio="none"><use xlink:href="#tabshape"></use></svg>
									<span>Get Quote</span>
								</a>
							</li>
							<li>
								<a href="#section-shape-4">
									<svg viewBox="0 0 80 60" preserveAspectRatio="none"><use xlink:href="#tabshape"></use></svg>
									<svg viewBox="0 0 80 60" preserveAspectRatio="none"><use xlink:href="#tabshape"></use></svg>
									<span>Analytics</span>
								</a>
							</li>
							<li>
								<a href="#section-shape-5">
									<svg viewBox="0 0 80 60" preserveAspectRatio="none"><use xlink:href="#tabshape"></use></svg>
									<span>Help</span>
								</a>
							</li>

							</ul>
					</nav>
					<div class="content-wrap">
						<!--section id="section-shape-1">
							<div align="left">
								<strong>Welcome to US Health Insurance Marketplace</strong>
								</br>
									<ul style="list-style-type:disc;" font-weight=200>
									  <li>Use <em><b>"Search"</b></em> tab to search and view plans and also edit them. </li>
									  </br>
									  <li>Use <em><b>"Create"</b></em> tab to create new plans. </li>
									  </br>
									  <li>Use <em><b>"Get Quote"</b></em> tab to enter your details and get a suitable quote. </li>
									  </br>
									  <li>Use <em><b>"Analytics"</b></em> tab to view various insightful analytical reports on insurance plans. </li>
									</ul>

								<font size="3" color="red">Note: </font>
								<font size="3" >
									<ul >
									  <li>Currently anyone can create and edit plans, feature to enable this only for admin users is work-in-progress. </li>
									  <li><em>"Analytics"</em> and <em>"Get Quote"</em> tabs are work-in-progress</li>
									</ul>


								</font>
							</div>


						</section-->



						<section id="section-shape-2">





						  <table class="table1">
							<tr class="tr1" align="left"> <td class="td1">Enter Details for Search</td></tr>
							<form >
							<tr class="tr3" align="left">
								<td class="td3">
									  Market Coverage: <input type="text" name="MarketCoverageSrch">
								</td>
								<td class="td3">

									  Benefit Types:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <input type="text" name="BenefitTypesSrch">
								</td>
								<td class="td3">
									  Coverge For:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="CovergeForSrch">
								</td>
							</tr>

							<tr class="tr3" align="left">
								<td class="td3">
									  Plan Type: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="PlanTypeSrch">
								</td>
								<td class="td3">
									  Drug Deductibles: <input type="text" name="MedicalDrugDeductiblesSrch">
								</td>
								<td class="td3">
									  Rate Lower Limit: <input type="text" name="RateLowerLimitSrch">
								</td>
							</tr>


							<tr class="tr3" align="left">
								<td class="td3">
									  Dental Only Plan: <input type="text" name="DentalOnlyPlanSrch">
								</td>
								<td class="td3">
									  Diseases Covered: <input type="text" name="DiseasesCoveredSrch">
								</td>
								<td class="td3">
									  Rate Upper Limit: <input type="text" name="RateUpperLimitSrch">
								</td>
							</tr>

							<tr class="tr3" align="left">
								<td class="td3">
									  Plan Id:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <input type="text" name="PlanIdSrch">
								</td>
								<td class="td3">

									<!--form class="form-items" action="" method="get">
									  Plan Name:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
									  <input type="text" name="PlanMarketingNameSrch">
									</form-->

										Plan Name:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
									<input type="text" name="PlanMarketingNameSrch" id="PlanMarketingNameSrch" />
									<br/>


								</td>
								<td class="td3">
								</td>
							</tr>

							<tr class="tr3" align="center">
								<td class="td3"></td>
								<td class="td3">

										<input type="submit" name="SearchButton" id="SearchButton" value="Search" /><br/>

								</td>
								<td class="td3"></td>
							</tr>
									</form>

						  </table>

























							</br>

						<table class="table1">
							<tr class="tr1" align="left"> <td class="td1">Search Results</td></tr>
						</table>

						<table class="table2" >

							<tr class="tr2" align="left">
								<td class="td2"><b>Plan Id</b></td>
								<td class="td2"><b>Plan Name</b></td>
								<td class="td2"><b>Plan Type</b></td>
								<td class="td2"><b>Market Coverage</b></td>
								<td class="td2"><b>Dental Only Plan</b></td>
								<td class="td2"><b>Approx Premium</b></td>
								<td class="td2"><b>View/Edit</b></td>
								<td class="td2"><b>Delete</b></td>
							</tr>


<?php
if(isset($_GET['SearchButton'])){ //check if form was submitted
  //$message = "Success! You entered: ".$input;
  // PlanId,PlanMarketingName,PlanType,MarketCoverage,DentalOnlyPlan,DiseasesCovered,
  // DrugDeductibles,MetalLevel,PlanBrochure,EnrollmentURL,BenefitsCoverageURL,NetworkId,ServiceAreaId
	$sqlquery = "SELECT distinct p.PlanId, p.PlanMarketingName, p.PlanType, p.MarketCoverage, p.DentalOnlyPlan, '70.34' as approxprem
	FROM public.plans p
	where lower(p.PlanMarketingName) like '%"; //%united%';
	$sqlquery .= $_GET['PlanMarketingNameSrch'];
	$sqlquery .= "%' order by p.planid;	";

	//var_dump($_POST);

	//echo $_GET['PlanMarketingNameSrch'];

	$result = pg_query($connection, $sqlquery);

		if (!$result) {
		  echo "<h1> An error occurred selecting data from the database </h1>";
		  exit;
		}


	while($query_data = pg_fetch_row($result)) {
	  echo "<tr class='tr222'>";
	  echo "<td class='td222'>",$query_data[0], "</td>",
		   "<td class='td222'>",$query_data[1], "</td>",
		   "<td class='td222'>",$query_data[2], "</td>",
		   "<td class='td222'>",$query_data[3], "</td>",
		   "<td class='td222'>",$query_data[4], "</td>",
		   "<td class='td222'>",$query_data[5], "</td>",
		   "<td class='td222'><form method='post'><input type='submit' name='EditButton' id='EditButton' value='View/Edit' /><br/></form></td>",
		   "<td class='td222'><form method='post'><input type='submit' name='DeleteButton' id='DeleteButton' value='Delete' /><br/></form></td>";
	  echo "</tr>";
	}

	// Free resultset
	pg_free_result($result);

	// Closing connection
//	pg_close($connection);

}
?>








<?php
///////////////////////////////
// THIS IS FOR DELETE BUTTON
///////////////////////////////
if(isset($_POST['DeleteButton'])){ //check if form was submitted
  //$message = "Success! You entered: ".$input;
  // PlanId,PlanMarketingName,PlanType,MarketCoverage,DentalOnlyPlan,DiseasesCovered,
  // DrugDeductibles,MetalLevel,PlanBrochure,EnrollmentURL,BenefitsCoverageURL,NetworkId,ServiceAreaId
	$delQuery = "delete from public.plans p where p.planid in ( ";
	$delQuery .= "SELECT distinct p.PlanId
	FROM public.plans p
	where lower(p.PlanMarketingName) like '%";
	$delQuery .= $_GET['PlanMarketingNameSrch'];
	$delQuery .= "%' order by p.planid LIMIT 1);	";

	$result = pg_query($connection, $delQuery);
	pg_free_result($result);


	//header("Refresh:0");
	//header('Location: '.$_SERVER['REQUEST_URI']);
	//echo "<script type='text/javascript'>window.location.reload();</script>";
	//$page = $_SERVER['PHP_SELF'];
	//$sec = "1";
	//header("Refresh: $sec; url=$page");

	echo "<script type='text/javascript'>alert('Record has been deleted');</script>";
	//echo "<script type='text/javascript'>if(!alert('Record has been deleted!')){window.location.reload();};</script>";


	// Free resultset
	pg_free_result($result);

	// Closing connection
	//pg_close($connection);

}
?>




<?php
///////////////////////////////
// THIS IS FOR VIEW/EDIT BUTTON
///////////////////////////////
if(isset($_POST['EditButton'])){ //check if form was submitted
  //$message = "Success! You entered: ".$input;
//	echo "<script type='text/javascript'>alert('Record has been deleted');</script>";

	$sqlquery = "select
p.PlanId, p.DiseasesCovered, p.BenefitsCoverageURL, s.StateCode,
p.PlanMarketingName, p.DrugDeductibles, p.NetworkId, s.ServiceAreaName,
p.PlanType, p.MetalLevel, n.NetworkName, s.CoverEntireState,
p.MarketCoverage, p.PlanBrochure, n.NetworkURL, s.ZipCodes,
p.DentalOnlyPlan, p.EnrollmentURL, p.ServiceAreaId,
b.BenefitName,b.LimitQty,b.Exclusions,
b.CoPay,b.LimitUnit,
r.RateType, r.RateSubType, r.Rate
from plans p,
benefits b,
rates r,
network n,
servicearea s
where p.planid = b.planid
and p.planid = r.planid
and p.networkid = n.networkid
and p.serviceareaid = s.serviceareaid
and lower(p.PlanMarketingName) like '%"; //%united%';
	$sqlquery .= $_GET['PlanMarketingNameSrch'];
	$sqlquery .= "%' order by p.planid LIMIT 1;	";

	//var_dump($_POST);

	//echo $_GET['PlanMarketingNameSrch'];

	$result = pg_query($connection, $sqlquery);

		if (!$result) {
		  echo "<h1> An error occurred selecting data from the database </h1>";
		  exit;
		}


	$query_data = pg_fetch_row($result);

	// Free resultset
	pg_free_result($result);


						echo "

						<table class='table1'>
							<tr class='tr1' align='left'> <td class='td1'><b>View/Edit Plan</b></td></tr>
						</table>

						<form method='post'>
						  <table class='table1'>
							<tr class='tr3' align='left'> <td class='td3'>Plan Details:</td></tr>
							<tr class='tr3' align='left'>
								<td class='td3'>
									  Plan Id:<br> <input type='text' name='EditPlanId' value='".$query_data[0]."'>
								</td>
								<td class='td3'>
									  DiseasesCovered:<br> <input type='text' name='EditDiseasesCovered' value='".$query_data[1]."'>
								</td>
								<td class='td3'>
									  Benefits Coverage URL:<br> <input type='text' name='EditBenefitsCoverageURL' value='".$query_data[2]."'>
								</td>
								<td class='td3'>
									  State Code:<br> <input type='text' name='EditStateCode' value='".$query_data[3]."'>
								</td>
							</tr>

							<tr class='tr3' align='left'>
								<td class='td3'>
									  Plan Marketing Name:<br> <input type='text' name='EditPlanMarketingName' value='".$query_data[4]."'>
								</td>
								<td class='td3'>
									  Drug Deductibles:<br> <input type='text' name='EditDrugDeductibles' value='".$query_data[5]."'>
								</td>
								<td class='td3'>
									  Network Id:<br> <input type='text' name='EditNetworkId' value='".$query_data[6]."'>
								</td>
								<td class='td3'>
									  Service Area Name:<br> <input type='text' name='EditServiceAreaName' value='".$query_data[7]."'>
								</td>
							</tr>


							<tr class='tr3' align='left'>
								<td class='td3'>
									  Plan Type:<br> <input type='text' name='EditPlanType' value='".$query_data[8]."'>
								</td>
								<td class='td3'>
									  Metal Level:<br> <input type='text' name='EditMetalLevel' value='".$query_data[9]."'>
								</td>
								<td class='td3'>
									  Network Name:<br> <input type='text' name='EditNetworkName' value='".$query_data[10]."'>
								</td>
								<td class='td3'>
									  Cover Entire State:<br> <input type='text' name='EditCoverEntireState' value='".$query_data[11]."'>
								</td>
							</tr>

							<tr class='tr3' align='left'>
								<td class='td3'>
									  Market Coverage:<br> <input type='text' name='EditMarketCoverage' value='".$query_data[12]."'>
								</td>
								<td class='td3'>
									  Plan Brochure:<br> <input type='text' name='EditPlan Brochure' value='".$query_data[13]."'>
								</td>
								<td class='td3'>
									  Network URL:<br> <input type='text' name='EditNetworkURL' value='".$query_data[14]."'>
								</td>
								<td class='td3'>
									  Zip Codes:<br> <input type='text' name='EditZipCodes' value='".$query_data[15]."'>
								</td>
							</tr>


							<tr class='tr3' align='left'>
								<td class='td3'>
									  Dental Only Plan:<br> <input type='text' name='EditDentalOnlyPlan' value='".$query_data[16]."'>
								</td>
								<td class='td3'>
									  Enrollment URL:<br> <input type='text' name='EditEnrollmentURL' value='".$query_data[17]."'>
								</td>
								<td class='td3'>
									  Service Area Id:<br> <input type='text' name='EditServiceAreaId' value='".$query_data[18]."'>
								</td>

							</tr>


							</table>



						</br>



						  <table class='table1'>
							<tr class='tr3' align='left'> <td class='td3'>Benefits Details:</td></tr>
							<tr class='tr3' align='left'>
								<td class='td3'>
									  Benefit Name:<br> <input type='text' name='EditBenefitName' value='".$query_data[19]."'>
								</td>
								<td class='td3'>
									  Limit Quantity:<br> <input type='text' name='EditLimitQty' value='".$query_data[20]."'>
								</td>
								<td class='td3'>
									  Exclusions:<br> <input type='text' name='EditExclusions' value='".$query_data[21]."'>
								</td>
							</tr>

							<tr class='tr3' align='left'>
								<td class='td3'>
									  CoPay:<br> <input type='text' name='EditCoPay' value='".$query_data[22]."'>
								</td>
								<td class='td3'>
									  LimitUnit:<br> <input type='text' name='EditLimitUnit' value='".$query_data[23]."'>
								</td>

							</tr>



						  </table>

							</br>

						  <table class='table1'>
							<tr class='tr3' align='left'> <td class='td3'>Rate Details:</td></tr>

							<tr class='tr3' align='left'>
								<td class='td3'>
									  Rate Type:<br> <input type='text' name='EditRateType' value='".$query_data[24]."'>
								</td>
								<td class='td3'>
									  Rate Sub Type:<br> <input type='text' name='EditRateSubType' value='".$query_data[25]."'>
								</td>
								<td class='td3'>
									  Rate:<br> <input type='text' name='EditRate' value='".$query_data[26]."'>
								</td>
							</tr>



						  </table>


						  <br>
						<input type='submit' name='SaveChanges' id='SaveChanges' value='Save Changes' /><br/>
						 </form>";


	// Free resultset
	pg_free_result($result);

	// Closing connection
	//pg_close($connection);

}
?>




<?php
///////////////////////////////
// THIS IS FOR VIEW/EDIT BUTTON
///////////////////////////////
if(isset($_POST['SaveChanges'])){ //check if form was submitted
  //$message = "Success! You entered: ".$input;
//	echo "<script type='text/javascript'>alert('Record has been deleted');</script>";

	$sqlquery = "update public.plans set PlanMarketingName = '".$_POST['EditPlanMarketingName']."' where planid in (select
p.PlanId
from plans p,
benefits b,
rates r,
network n,
servicearea s
where p.planid = b.planid
and p.planid = r.planid
and p.networkid = n.networkid
and p.serviceareaid = s.serviceareaid
and lower(p.PlanMarketingName) like '%"; //%united%';
	$sqlquery .= $_GET['PlanMarketingNameSrch'];
	$sqlquery .= "%' order by p.planid LIMIT 1);	";

	//var_dump($_POST);

	//echo $_GET['PlanMarketingNameSrch'];

	$result = pg_query($connection, $sqlquery);

	echo "<script type='text/javascript'>alert('Record UPDATED successfully');</script>";
	//echo "<script type='text/javascript'>if(!alert('Record UPDATED successfully')){window.location.reload();};</script>";


	//$query_data = pg_fetch_row($result);

	// Free resultset
	pg_free_result($result);

	// Free resultset
	pg_free_result($result);

	// Closing connection
	//pg_close($connection);

}
?>



							</table>


						</section>



						<section id="section-shape-2">

					<form>


						  <table class="table1">
							<tr class="tr3" align="left"> <td class="td3">Enter Plan Details:</td></tr>
							<tr class="tr3" align="left">
								<td class="td3">
									  Plan Id:<br> <input type="text" name="PlanId">
								</td>
								<td class="td3">
									  DiseasesCovered:<br> <input type="text" name="DiseasesCovered">
								</td>
								<td class="td3">
									  Benefits Coverage URL:<br> <input type="text" name="BenefitsCoverageURL">
								</td>
								<td class="td3">
									  State Code:<br> <input type="text" name="StateCode">
								</td>
							</tr>

							<tr class="tr3" align="left">
								<td class="td3">
									  Plan Marketing Name:<br> <input type="text" name="PlanMarketingName">
								</td>
								<td class="td3">
									  Drug Deductibles:<br> <input type="text" name="DrugDeductibles">
								</td>
								<td class="td3">
									  Network Id:<br> <input type="text" name="NetworkId">
								</td>
								<td class="td3">
									  Service Area Name:<br> <input type="text" name="ServiceAreaName">
								</td>
							</tr>


							<tr class="tr3" align="left">
								<td class="td3">
									  Plan Type:<br> <input type="text" name="PlanType">
								</td>
								<td class="td3">
									  Metal Level:<br> <input type="text" name="MetalLevel">
								</td>
								<td class="td3">
									  Network Name:<br> <input type="text" name="NetworkName">
								</td>
								<td class="td3">
									  Cover Entire State:<br> <input type="text" name="CoverEntireState">
								</td>
							</tr>

							<tr class="tr3" align="left">
								<td class="td3">
									  Market Coverage:<br> <input type="text" name="MarketCoverage">
								</td>
								<td class="td3">
									  Plan Brochure:<br> <input type="text" name="Plan Brochure">
								</td>
								<td class="td3">
									  Network URL:<br> <input type="text" name="NetworkURL">
								</td>
								<td class="td3">
									  Zip Codes:<br> <input type="text" name="ZipCodes">
								</td>
							</tr>


							<tr class="tr3" align="left">
								<td class="td3">
									  Dental Only Plan:<br> <input type="text" name="DentalOnlyPlan">
								</td>
								<td class="td3">
									  Enrollment URL:<br> <input type="text" name="EnrollmentURL">
								</td>
								<td class="td3">
									  Service Area Id:<br> <input type="text" name="ServiceAreaId">
								</td>

							</tr>


							</table>



						</br>



						  <table class="table1">
							<tr class="tr3" align="left"> <td class="td3">Enter Benefits Details:</td></tr>
							<tr class="tr3" align="left">
								<td class="td3">
									  Benefit Name:<br> <input type="text" name="BenefitName">
								</td>
								<td class="td3">
									  Limit Quantity:<br> <input type="text" name="LimitQty">
								</td>
								<td class="td3">
									  Exclusions:<br> <input type="text" name="Exclusions">
								</td>
							</tr>

							<tr class="tr3" align="left">
								<td class="td3">
									  CoPay:<br> <input type="text" name="CoPay">
								</td>
								<td class="td3">
									  LimitUnit:<br> <input type="text" name="LimitUnit">
								</td>

							</tr>



						  </table>

							</br>

						  <table class="table1">
							<tr class="tr3" align="left"> <td class="td3">Enter Rate Details:</td></tr>

							<tr class="tr3" align="left">
								<td class="td3">
									  Rate Type:<br> <input type="text" name="RateType">
								</td>
								<td class="td3">
									  Rate Sub Type:<br> <input type="text" name="RateSubType">
								</td>
								<td class="td3">
									  Rate:<br> <input type="text" name="Rate">
								</td>
							</tr>



						  </table>


						  <br>
						  <!--button type="button" onclick="alert('You pressed the button!')">Create Plan</button-->
						<input type="submit" name="CreatePlan" id="CreatePlan" value="Create Plan" /><br/>
						 </form>


<?php
///////////////////////////////
// THIS IS FOR CREATE PLAN BUTTON
///////////////////////////////
if(isset($_GET['CreatePlan'])){ //check if form was submitted
  // insert into plans
    // PlanId,PlanMarketingName,PlanType,MarketCoverage,DentalOnlyPlan,DiseasesCovered,
  // DrugDeductibles,MetalLevel,PlanBrochure,EnrollmentURL,BenefitsCoverageURL,NetworkId,ServiceAreaId

  $insertQuery = "insert into public.plans ( PlanId,PlanMarketingName,PlanType,MarketCoverage,DentalOnlyPlan,DiseasesCovered,
		DrugDeductibles,MetalLevel,PlanBrochure,EnrollmentURL,BenefitsCoverageURL,
		NetworkId,ServiceAreaId) values ('";

	$insertQuery .= $_GET['PlanId']."','";
	$insertQuery .= $_GET['PlanMarketingName']."','";
	$insertQuery .= $_GET['PlanType']."','";
	$insertQuery .= $_GET['MarketCoverage']."','";
	$insertQuery .= $_GET['DentalOnlyPlan']."','";
	$insertQuery .= $_GET['DiseasesCovered']."','";
	$insertQuery .= $_GET['DrugDeductibles']."','";
	$insertQuery .= $_GET['MetalLevel']."','";
	$insertQuery .= $_GET['PlanBrochure']."','";
	$insertQuery .= $_GET['EnrollmentURL']."','";
	$insertQuery .= $_GET['BenefitsCoverageURL']."','";
	$insertQuery .= $_GET['NetworkId']."','";
	$insertQuery .= $_GET['ServiceAreaId']."');";


	$result = pg_query($connection, $insertQuery);
	pg_free_result($result);

  // insert into subject area
//  ServiceAreaId,StateCode,ServiceAreaName,CoverEntireState,ZipCodes
  $insertQuery = "insert into public.servicearea ( ServiceAreaId,StateCode,ServiceAreaName,CoverEntireState,ZipCodes) values ('";
	$insertQuery .= $_GET['ServiceAreaId']."','";
	$insertQuery .= $_GET['StateCode']."','";
	$insertQuery .= $_GET['ServiceAreaName']."','";
	$insertQuery .= $_GET['CoverEntireState']."','";
	$insertQuery .= $_GET['ZipCodes']."');";


	$result = pg_query($connection, $insertQuery);
	pg_free_result($result);


  // insert into network
  //NetworkId,NetworkName,NetworkURL
  $insertQuery = "insert into public.network ( NetworkId,NetworkName,NetworkURL) values ('";
	$insertQuery .= $_GET['NetworkId']."','";
	$insertQuery .= $_GET['NetworkName']."','";
	$insertQuery .= $_GET['NetworkURL']."');";


	$result = pg_query($connection, $insertQuery);
	pg_free_result($result);


  // insert into rates
//PlanId,RateType,RateSubType,Rate
  $insertQuery = "insert into public.rates ( PlanId,RateType,RateSubType,Rate) values ('";
	$insertQuery .= $_GET['PlanId']."','";
	$insertQuery .= $_GET['RateType']."','";
	$insertQuery .= $_GET['RateSubType']."','";
	$insertQuery .= $_GET['Rate']."');";


	$result = pg_query($connection, $insertQuery);
	pg_free_result($result);



  // insert into benefits
//PlanId,BenefitName,CoPay,LimitQty,LimitUnit,Exclusions
  $insertQuery = "insert into public.benefits ( PlanId,BenefitName,CoPay,LimitQty,LimitUnit,Exclusions) values ('";
	$insertQuery .= $_GET['PlanId']."','";
	$insertQuery .= $_GET['BenefitName']."','";
	$insertQuery .= $_GET['CoPay']."','";
	$insertQuery .= $_GET['LimitQty']."','";
	$insertQuery .= $_GET['LimitUnit']."','";
	$insertQuery .= $_GET['Exclusions']."');";

	$result = pg_query($connection, $insertQuery);
	pg_free_result($result);



	echo "<script type='text/javascript'>alert('Record Created Successfully');</script>";


	// Free resultset
	pg_free_result($result);

	// Closing connection
	//pg_close($connection);

}
?>




						</section>





						<section id="section-shape-3"><p>Work in Progress</p></section>
						<section id="section-shape-4"><p>Work in Progress</p></section>

						<section id="section-shape-5">
							<div align="left">
								<strong>Welcome to US Health Insurance Marketplace</strong>
								</br>
									<ul style="list-style-type:disc;" font-weight=200>
									  <li>Use <em><b>"Search"</b></em> tab to search and view plans and also edit them. </li>
									  </br>
									  <li>Use <em><b>"Create"</b></em> tab to create new plans. </li>
									  </br>
									  <li>Use <em><b>"Get Quote"</b></em> tab to enter your details and get a suitable quote. </li>
									  </br>
									  <li>Use <em><b>"Analytics"</b></em> tab to view various insightful analytical reports on insurance plans. </li>
									</ul>

								<font size="3" color="red">Note: </font>
								<font size="3" >
									<ul >
									  <li>Currently anyone can create and edit plans, feature to enable this only for admin users is work-in-progress. </li>
									  <li><em>"Analytics"</em> and <em>"Get Quote"</em> tabs are work-in-progress</li>
									</ul>


								</font>
							</div>


						</section>




					</div>
				</div>
			</section>








			<script src="js/cbpFWTabs.js"></script>
		<script>
			(function() {

				[].slice.call( document.querySelectorAll( '.tabs' ) ).forEach( function( el ) {
					new CBPFWTabs( el );
				});

			})();
		</script>
	</body>
</html>
